param(
    [string]$ManifestUrl = '',
    [string]$ZipPath = '',
    [switch]$NoConfirm,
    [switch]$StartCore
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$root = Split-Path -Parent $PSCommandPath
$api = 'http://127.0.0.1:8720'

function Get-Meta {
    try { return Invoke-RestMethod -Uri "$api/api/meta" -TimeoutSec 4 } catch { return $null }
}

function Start-App([string]$exe) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.WorkingDirectory = $root
    $psi.UseShellExecute = $false
    [System.Diagnostics.Process]::Start($psi) | Out-Null
}

function Start-Launcher {
    if ($StartCore) {
        Start-App (Join-Path $root 'AULA_LED_Core.exe')
    } else {
        Start-App (Join-Path $root 'AULA_LED.exe')
    }
}

function Wait-Meta([double]$seconds) {
    $deadline = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $deadline) {
        $m = Get-Meta
        if ($m -and $m.version) { return $m }
        Start-Sleep -Milliseconds 500
    }
    return $null
}

function Parse-Ver([string]$v) {
    $parts = ($v -replace '^v', '') -split '[.\-+_]'
    $nums = @()
    foreach ($p in $parts) {
        $n = 0
        if ([int]::TryParse($p, [ref]$n)) { $nums += $n } else { $nums += 0 }
    }
    return ,$nums
}

function Compare-Ver([string]$a, [string]$b) {
    $x = Parse-Ver $a
    $y = Parse-Ver $b
    $len = [Math]::Max($x.Count, $y.Count)
    for ($i = 0; $i -lt $len; $i++) {
        $v = 0; $w = 0
        if ($i -lt $x.Count) { $v = $x[$i] }
        if ($i -lt $y.Count) { $w = $y[$i] }
        if ($v -ne $w) { return [Math]::Sign($v - $w) }
    }
    return 0
}

Write-Host ''
Write-Host 'AULA LED updater'
Write-Host '----------------'

if (-not $ManifestUrl) {
    $cfgPath = Join-Path $root '_internal\web\update.json'
    if (-not (Test-Path $cfgPath)) { throw "Missing _internal\web\update.json" }
    $cfg = Get-Content -Path $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $ManifestUrl = $cfg.manifest
}
if (-not $ManifestUrl) { throw 'No manifest URL configured.' }
Write-Host "Manifest : $ManifestUrl"

$info = Invoke-RestMethod -Uri $ManifestUrl -TimeoutSec 20
if (-not $info.version) { throw 'Manifest has no version.' }
Write-Host "Latest   : $($info.version)"

$meta = Get-Meta
if (-not $meta) {
    Write-Host 'App not running, starting it to read the current version...'
    Start-App (Join-Path $root 'AULA_LED_Core.exe')
    $meta = Wait-Meta 40
}
if (-not $meta) { throw 'Cannot read the current app version.' }

$current = [string]$meta.version
Write-Host "Current  : $current"

if ((Compare-Ver $info.version $current) -le 0) {
    Write-Host 'Already up to date.'
    exit 0
}

$zips = @()
if ($ZipPath) {
    $zips = @(Get-Item -Path $ZipPath)
} else {
    $dirs = @((Join-Path $env:USERPROFILE 'Downloads'), $root)
    foreach ($d in $dirs) {
        if (-not (Test-Path $d)) { continue }
        $found = Get-ChildItem -Path $d -Filter 'AULA_LED_*.zip' -File -ErrorAction SilentlyContinue
        if ($found) { $zips += $found }
    }
    $zips = $zips | Sort-Object LastWriteTime -Descending
}
if (-not $zips) { throw 'No AULA_LED_*.zip found. Download the update package first.' }

$zip = $null
foreach ($z in $zips) {
    $hash = (Get-FileHash -Path $z.FullName -Algorithm SHA256).Hash
    if ($info.sha256 -and $hash -ne $info.sha256) {
        Write-Host "Skip (hash mismatch): $($z.Name)"
        continue
    }
    if ($info.size -and $z.Length -ne [int64]$info.size) {
        Write-Host "Skip (size mismatch): $($z.Name)"
        continue
    }
    $zip = $z
    break
}
if (-not $zip) { throw 'No downloaded package matches the manifest hash.' }
Write-Host "Package  : $($zip.FullName)"

if (-not $NoConfirm) {
    $ans = Read-Host 'Update now? The app will be closed. [y/N]'
    if ($ans -notmatch '^(y|yes)$') { Write-Host 'Cancelled.'; exit 0 }
}

Write-Host 'Closing app...'
try {
    Invoke-RestMethod -Uri "$api/api/quit" -Method Post -Body '{}' -ContentType 'application/json' -TimeoutSec 5 | Out-Null
} catch { }
$deadline = (Get-Date).AddSeconds(40)
while ((Get-Date) -lt $deadline) {
    if (-not (Get-Meta)) { break }
    Start-Sleep -Milliseconds 500
}
if (Get-Meta) { throw 'App did not exit; nothing was changed.' }

$tmp = Join-Path $env:TEMP ('aula_update_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $tmp | Out-Null
Write-Host 'Extracting package...'
Expand-Archive -Path $zip.FullName -DestinationPath $tmp -Force

$preserve = @('effects_custom', 'studio', 'model_data', 'settings.json', 'AULA_LED.log', '更新.ps1', '更新.bat')
$newItems = @(Get-ChildItem -Path $tmp | Where-Object { $preserve -notcontains $_.Name })
if (-not ($newItems | Where-Object { $_.Name -eq 'AULA_LED_Core.exe' })) {
    throw 'Bad package: AULA_LED_Core.exe missing.'
}

$backup = Join-Path $tmp '_backup'
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($it in $newItems) {
    $dest = Join-Path $root $it.Name
    if (Test-Path $dest) {
        Move-Item -Path $dest -Destination (Join-Path $backup $it.Name) -Force
    }
}
foreach ($it in $newItems) {
    Copy-Item -Path $it.FullName -Destination (Join-Path $root $it.Name) -Recurse -Force
}
foreach ($n in @('更新.ps1', '更新.bat')) {
    $src = Join-Path $tmp $n
    if (Test-Path $src) { Copy-Item -Path $src -Destination (Join-Path $root $n) -Force -ErrorAction SilentlyContinue }
}

Write-Host 'Starting new version...'
$ok = $null
try {
    Start-Launcher
    $deadline = (Get-Date).AddSeconds(60)
    while ((Get-Date) -lt $deadline) {
        $m = Get-Meta
        if ($m -and $m.version -and (Compare-Ver $m.version $info.version) -ge 0) { $ok = $m; break }
        Start-Sleep -Milliseconds 700
    }
} catch {
    Write-Host "Start failed: $($_.Exception.Message)"
}

if (-not $ok) {
    Write-Host 'Update failed, rolling back...'
    Get-Process -Name 'AULA_LED_Core' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process -Name 'AULA_LED' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    foreach ($it in $newItems) {
        Remove-Item -Path (Join-Path $root $it.Name) -Recurse -Force -ErrorAction SilentlyContinue
    }
    Get-ChildItem -Path $backup | ForEach-Object {
        Move-Item -Path $_.FullName -Destination (Join-Path $root $_.Name) -Force
    }
    try { Start-Launcher } catch { Write-Host "Old version did not start: $($_.Exception.Message)" }
    throw 'Update failed; rolled back to the previous version.'
}

Write-Host "Updated to $($ok.version)."
Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Done.'
