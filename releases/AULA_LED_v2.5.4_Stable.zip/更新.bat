@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   AULA LED 更新器
echo   会先关闭正在运行的程序，再替换文件；失败会自动回滚。
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0更新.ps1" %*
echo.
pause
