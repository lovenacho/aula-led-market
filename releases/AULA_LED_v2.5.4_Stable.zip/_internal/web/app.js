const $ = (id) => document.getElementById(id);

let META = null;
let LAYOUTS = {};   // {profileName: layout} —— 编辑器可在两把键盘的布局间切换
let keyEls = new Map();
let polling = true;
let missCount = 0;   // 轮询连续失败次数：偶尔一次失败不算掉线
let paintMode = false;
let currentColor = [0, 160, 255];
let probeMode = false;
let probeState = null;

const SWATCHES = ['#00a0ff', '#8b5cf6', '#22e08a', '#ffd23f', '#ff5f6d', '#ff8a3d', '#ffffff'];
const BG_SWATCHES = ['#050510', '#0a0a1a', '#101828', '#001a12', '#1a0a20', '#1a1200', '#ffffff'];

// 市场源按顺序尝试：GitHub/jsDelivr 优先，失败时回落到程序自带的 demo 市场。
// 先向 GitHub API 查 main 的最新 commit，再用不可变 commit URL 读索引，绕开 @main 缓存。
// 也可以在浏览器控制台设置 window.AULA_MARKET_URL 临时覆盖。
const MARKET_LOCAL_URL = 'market/index.json';
// 当前已经包含删除测试动画的提交；GitHub API 不可用时用它兜底，避免 raw 分支缓存。
const MARKET_FALLBACK_COMMIT = 'e78456c6d242a3fc91c4cad9d07a761bb4e4bd5e';
const MARKET_FALLBACK_RAW = 'https://raw.githubusercontent.com/lovenacho/aula-led-market/'
  + MARKET_FALLBACK_COMMIT + '/index.json';
const MARKET_INDEX_URLS = window.AULA_MARKET_URL
  ? [window.AULA_MARKET_URL, MARKET_LOCAL_URL]
  : [
    MARKET_FALLBACK_RAW,
    'https://cdn.jsdelivr.net/gh/lovenacho/aula-led-market@main/index.json',
    'https://fastly.jsdelivr.net/gh/lovenacho/aula-led-market@main/index.json',
    'https://gcore.jsdelivr.net/gh/lovenacho/aula-led-market@main/index.json',
    'https://raw.githack.com/lovenacho/aula-led-market/main/index.json',
    MARKET_LOCAL_URL,
  ];
let MARKET_BASE_URL = null;
let MARKET = null;
let MARKET_INSTALLED = new Set();
let marketLoading = false;

async function api(path, body) {
  const isGet = body === undefined;
  // WebView2 有时会把 /api/state 这种 GET 当成可缓存资源，导致独立窗口一直
  // 显示旧的 connected=false；浏览器窗口缓存是空的所以看起来正常。
  // 对 GET 请求加时间戳并显式 no-store，保证每次拿到的都是当前状态。
  let url = path;
  if (isGet && path.startsWith('/api/')) {
    url += (path.includes('?') ? '&' : '?') + '_=' + Date.now();
  }
  const ctrl = new AbortController();
  // 状态轮询可以短超时；保存工程/检查插件这种 POST 可能本来就慢，给足时间。
  const timer = setTimeout(() => ctrl.abort(), isGet ? 4000 : 60000);
  try {
    const res = await fetch(url, {
      method: isGet ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: isGet ? undefined : JSON.stringify(body),
      cache: 'no-store',
      signal: ctrl.signal,
    });
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

function hexToRgb(hex) {
  const v = hex.replace('#', '');
  return [parseInt(v.slice(0, 2), 16), parseInt(v.slice(2, 4), 16), parseInt(v.slice(4, 6), 16)];
}
function rgbToHex(rgb) {
  return '#' + rgb.map((c) => Math.max(0, Math.min(255, c)).toString(16).padStart(2, '0')).join('');
}

function buildKeyboard(layout) {
  const kb = $('keyboard');
  kb.innerHTML = '';
  keyEls.clear();
  layout.forEach((row) => {
    const rowEl = document.createElement('div');
    rowEl.className = 'kb-row';
    row.forEach((key) => {
      const el = document.createElement('div');
      el.className = 'key' + (key.label.length > 3 ? ' small' : '');
      el.style.setProperty('--w', key.w);
      el.textContent = key.label;
      el.dataset.key = key.id;
      el.addEventListener('click', () => {
        if (probeMode) { probeAction('move', { key: key.id }); return; }
        if (!paintMode) return;
        api('/api/paint', { key: key.id, color: currentColor });
      });
      el.addEventListener('contextmenu', (ev) => {
        ev.preventDefault();
        if (!paintMode) return;
        api('/api/paint', { key: key.id, color: null });
      });
      rowEl.appendChild(el);
      keyEls.set(String(key.id), el);
    });
    kb.appendChild(rowEl);
  });
}

function renderEffects(effects) {
  const box = $('effects');
  box.innerHTML = '';
  effects.forEach((eff) => {
    const btn = document.createElement('button');
    btn.className = 'eff';
    btn.dataset.id = eff.id;
    btn.innerHTML = `${eff.label}<span class="cat">${eff.category}</span>`;
    btn.addEventListener('click', async () => {
      await api('/api/effect', { id: eff.id });
      markActive(eff.id);
    });
    box.appendChild(btn);
  });
  const count = $('fxCount');
  if (count) count.textContent = effects.length + ' 个';
}

function markActive(id) {
  document.querySelectorAll('.eff').forEach((el) => {
    el.classList.toggle('active', el.dataset.id === id);
  });
}

function applyColor(el, rgb, pressed) {
  const [r, g, b] = rgb;
  const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  el.style.backgroundColor = `rgb(${r},${g},${b})`;
  el.style.color = lum > 0.55 ? 'rgba(0,0,0,0.72)' : 'rgba(200,215,235,0.55)';
  el.style.boxShadow = lum > 0.06
    ? `0 0 ${Math.round(4 + lum * 12)}px rgba(${r},${g},${b},${0.28 + lum * 0.35})`
    : 'none';
  el.classList.toggle('pressed', pressed);
}

function makeSwatches(boxId, colors, onPick) {
  const box = $(boxId);
  box.innerHTML = '';
  colors.forEach((hex) => {
    const el = document.createElement('div');
    el.className = 'sw';
    el.style.background = hex;
    el.title = hex;
    el.addEventListener('click', () => onPick(hex));
    box.appendChild(el);
  });
}

// ---------- 刷新率 ----------
let fpsDragging = false;

// ---------- 编辑器画笔的自定义颜色 ----------
// 收藏的颜色存在浏览器 localStorage 里，和默认色板合并显示；
// 末尾的「+」把当前画笔颜色收进来，右键收藏的色块删除。
const BRUSH_STORE_KEY = 'aula_brush_colors';

function loadBrushColors() {
  try {
    const list = JSON.parse(localStorage.getItem(BRUSH_STORE_KEY) || '[]');
    return Array.isArray(list)
      ? list.filter((c) => typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c)).slice(0, 24)
      : [];
  } catch (err) {
    return [];
  }
}

function saveBrushColors() {
  try {
    localStorage.setItem(BRUSH_STORE_KEY, JSON.stringify(customBrushColors));
  } catch (err) { /* 隐身模式等存不了就算了 */ }
}

let customBrushColors = loadBrushColors();

function pickBrush(hex) {
  $('brush').value = hex;
  S.brush = hexToRgb(hex);
  S.eraser = false;
  $('eraser').classList.remove('on');
  $('studioKeyboard').style.cursor = '';
}

function renderBrushSwatches() {
  const box = $('brushSwatches');
  box.innerHTML = '';
  [...SWATCHES, ...customBrushColors].forEach((hex) => {
    const el = document.createElement('div');
    el.className = 'sw';
    el.style.background = hex;
    if (customBrushColors.includes(hex)) {
      el.title = hex + '（右键删除）';
      el.addEventListener('contextmenu', (ev) => {
        ev.preventDefault();
        customBrushColors = customBrushColors.filter((c) => c !== hex);
        saveBrushColors();
        renderBrushSwatches();
      });
    } else {
      el.title = hex;
    }
    el.addEventListener('click', () => pickBrush(hex));
    box.appendChild(el);
  });
  const add = document.createElement('div');
  add.className = 'sw add';
  add.textContent = '+';
  add.title = '把当前画笔颜色收藏到这里';
  add.addEventListener('click', () => {
    const hex = rgbToHex(S.brush);
    if (!customBrushColors.includes(hex)) {
      customBrushColors.push(hex);
      saveBrushColors();
    }
    pickBrush(hex);
    renderBrushSwatches();
  });
  box.appendChild(add);
}
let brightnessDragging = false;
let speedDragging = false;
let bgDragging = false;
let fpsTimer = null;
let bgTimer = null;

function setFpsLabel(target, actual) {
  const a = (actual === null || actual === undefined) ? '--' : Number(actual).toFixed(0);
  $('fpsVal').textContent = `设定 ${target} · 实际 ${a}`;
}

function applyFps(v) {
  const val = Math.max(15, Math.min(60, Math.round(Number(v) || 40)));
  $('fpsRange').value = val;
  setFpsLabel(val, null);
  api('/api/params', { fps: val });
}

// 从后端状态回填所有控件，避免页面停留在旧值上
// 注意：用户正在拖动的滑块不能被回填，否则拖到 0 会被上一帧的值弹回去
// （「背光调不到无光」就是这么来的）。
function syncControls(s) {
  if (s.brightness != null && !brightnessDragging) {
    const b = Math.round(s.brightness * 100);
    $('brightness').value = b;
    $('brightnessVal').textContent = b + '%';
  }
  if (s.speed != null && !speedDragging) {
    const sp = Math.round(s.speed * 100);
    $('speed').value = sp;
    $('speedVal').textContent = (sp / 100).toFixed(1) + 'x';
  }
  if (s.bg_level != null && !bgDragging) {
    const g = Math.round(s.bg_level * 100);
    $('bgLevel').value = g;
    $('bgLevelVal').textContent = g + '%';
  }
  if (s.color) $('colorPicker').value = rgbToHex(s.color);
  if (s.bg) $('bgPicker').value = rgbToHex(s.bg);
  if (s.fps_target && !fpsDragging) $('fpsRange').value = s.fps_target;
  if (s.fps_target) setFpsLabel(s.fps_target, s.fps);
  renderChips(s);
}

// 键盘下方的状态摘要条：一眼看到「现在到底在跑什么」
// 拖动中的滑块用控件自己的值，否则会被上一帧的旧状态弹回去
function renderChips(s) {
  if (!s) return;
  const eff = ((META && META.effects) || []).find((e) => e.id === s.effect);
  if (eff) $('sumEffect').textContent = eff.label;
  if (s.color) {
    const hex = rgbToHex(s.color);
    $('sumColor').textContent = hex.toUpperCase();
    $('sumColorDot').style.background = hex;
  }
  const bright = brightnessDragging
    ? Number($('brightness').value)
    : Math.round((s.brightness ?? 0.85) * 100);
  $('sumBright').textContent = bright + '%';
  const bgv = bgDragging
    ? Number($('bgLevel').value)
    : Math.round((s.bg_level ?? 0.25) * 100);
  $('sumBg').textContent = bgv + '%';
  const spd = speedDragging ? Number($('speed').value) : Math.round((s.speed ?? 1) * 100);
  $('sumSpeed').textContent = (spd / 100).toFixed(1) + 'x';
  if (s.fps_target) {
    $('sumFps').textContent = s.fps != null
      ? `${s.fps_target} / ${Number(s.fps).toFixed(0)}`
      : String(s.fps_target);
  }
}

async function tick() {
  if (!polling) return;
  try {
    const s = await api('/api/state');
    missCount = 0;                     // 成功一次就把失败计数清零
    $('statusDot').classList.toggle('on', s.connected);
    $('statusText').textContent = (s.model ? s.model + ' · ' : '') + (s.connected ? '已连接' : '未连接');
    $('modelBadge').hidden = !!s.model_ok;
    $('modelBadge').textContent = s.model_ok ? '' : '键位待核对';
    $('fps').textContent = s.fps.toFixed(0);
    $('frames').textContent = s.frames;
    $('leds').textContent = s.leds;
    markActive(s.effect);
    S.studio = !!s.studio;   // 记录预览状态，离开编辑器标签时据此退出
    // 这两层会盖住灯效/背光，用状态栏明确提示，否则用户会以为「背光关不掉」
    $('flagStudio').hidden = !s.studio;
    $('flagPaint').hidden = !s.paint_mode;
    if (s.fps_target) {
      if (!fpsDragging) $('fpsRange').value = s.fps_target;
      setFpsLabel(s.fps_target, s.fps);
    }
    renderChips(s);

    const pressed = new Set(s.pressed.map(String));
    Object.entries(s.colors).forEach(([key, rgb]) => {
      const el = keyEls.get(key);
      if (el) applyColor(el, rgb, pressed.has(key));
    });

    // 编辑器正在播放时，让编辑器里的键盘也实时跟着动
    if (S.playing && !$('stage-studio').hidden) {
      S.els.forEach((el, id) => {
        const rgb = s.colors[id];
        if (rgb) applyColor(el, rgb, false);
      });
    }

    document.querySelectorAll('#keyboard .key').forEach((el) => {
      el.classList.toggle('painted', paintMode && s.paint && s.paint[el.dataset.key] !== undefined);
    });

    const bar = $('errorbar');
    if (s.error) {
      bar.hidden = false;
      bar.textContent = s.error;
    } else {
      bar.hidden = true;
    }
  } catch (err) {
    // 本机端口偶尔抽风（WinError 10013）不代表键盘掉了：这里只累计。
    // 但连续失败要给出“重试中”提示，不能一直停在旧状态（比如旧页面
    // 缓存下来的“未连接”），否则用户会以为驱动没连上。
    missCount += 1;
    if (missCount >= 5) {
      $('statusDot').classList.remove('on');
      $('statusText').textContent = '连接异常，正在重试…';
    }
  } finally {
    setTimeout(tick, missCount ? 300 : 150);
  }
}

function setupModelSwitch(meta) {
  // 有别的机型在线时显示「切换」按钮，点击后程序自动重启并换过去
  const btn = $('modelSwitch');
  const others = meta.switchable || [];
  if (!others.length) { btn.hidden = true; return; }
  btn.hidden = false;
  btn.textContent = '⇄ 切到 ' + others[0].title;
  btn.onclick = async () => {
    if (btn.dataset.busy) return;
    btn.dataset.busy = '1';
    btn.textContent = '切换中…';
    try {
      await api('/api/model', { name: others[0].name });
      btn.textContent = '已切换，重启中…';
    } catch (err) {
      btn.textContent = '切换失败';
      delete btn.dataset.busy;
    }
  };
}

async function loadSettings() {
  try {
    const res = await api('/api/settings');
    if (!res || !res.settings) return;
    $('keepOnExit').checked = !!res.settings.keep_on_exit;
    $('autostart').checked = !!res.autostart;
  } catch (err) {
    /* 老版本后端没有这个接口，忽略即可 */
  }
}

async function loadMeta() {
  let last = null;
  // 独立窗口刚创建时偶尔会比 HTTP 线程早一点点发请求；浏览器打开时服务
  // 已经稳定，所以只有独立窗口会出现白屏/一直“连接中”。
  for (let attempt = 0; attempt < 8; attempt++) {
    try {
      const meta = await api('/api/meta');
      if (meta && meta.layout) return meta;
      last = new Error('meta 数据不完整');
    } catch (err) {
      last = err;
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw last || new Error('无法连接控制台');
}

const MODEL_TITLES_FALLBACK = {
  win60se: 'WIN 60 SE',
  win60he: 'WIN 60 HE',
  win60hepro: 'WIN 60 HE PRO',
  win60hemax: 'WIN 60 HE MAX',
  win68he: 'WIN 68 HE',
  mini60pro: 'MINI 60 HE PRO',
};

function escModelText(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function renderModelList(meta) {
  const list = $('modelsList');
  if (!list) return;
  const titles = (meta && meta.titles) || MODEL_TITLES_FALLBACK;
  const current = (meta && meta.model_name) || '';
  const available = new Set((meta && meta.available) || []);
  $('modelsCurrent').textContent = (meta && (meta.model || titles[current])) || '未检测到键盘';
  const rows = Object.keys(titles)
    .map((key) => ({ key, title: titles[key] }))
    .sort((a, b) => a.title.localeCompare(b.title));
  list.innerHTML = rows.map(({ key, title }) => {
    const isCurrent = key === current;
    const isOnline = available.has(title) || isCurrent;
    const tag = isCurrent ? '当前设备' : (isOnline ? '在线' : '支持');
    return '<div class="model-item' + (isCurrent ? ' current' : '') + '">'
      + '<span>' + escModelText(title) + '</span>'
      + '<span class="tag' + (isCurrent || isOnline ? '' : ' off') + '">' + tag + '</span>'
      + '</div>';
  }).join('');
}

async function openModelList() {
  const mask = $('modelsMask');
  if (!mask) return;
  mask.hidden = false;
  let meta = META;
  if (!meta || !meta.titles) {
    try { meta = await api('/api/meta'); } catch (err) { meta = META; }
  }
  renderModelList(meta);
}

function initModelList() {
  const btn = $('modelsBtn');
  const mask = $('modelsMask');
  if (!btn || !mask) return;
  btn.addEventListener('click', openModelList);
  $('modelsClose').addEventListener('click', () => { mask.hidden = true; });
  mask.addEventListener('click', (ev) => { if (ev.target === mask) mask.hidden = true; });
}

async function boot() {
  try {
    META = await loadMeta();
  } catch (err) {
    const status = $('statusText');
    if (status) status.textContent = '连接失败，正在重试…';
    setTimeout(boot, 1000);
    return;
  }
  $('modelTitle').textContent = '逐键灯光台';
  // 版本号以后端为准（单一来源 aula/version.py），页面写死的只是兜底
  if (META.version) {
    $('verBadge').textContent = META.version;
    $('verFoot').textContent = META.version;
  }
  setupModelSwitch(META);
  LAYOUTS = META.layouts || { current: META.layout };
  S.layoutModel = META.model_name || Object.keys(LAYOUTS)[0];
  buildKeyboard(META.layout);
  buildCoords(META.layout);
  buildStudioKeyboard(LAYOUTS[S.layoutModel] || META.layout);
  buildLayoutSwitch();
  bindStudio();
  initModelList();
  renderTimeline();
  paintStudioFrame();
  loadProjects();
  // 支持 /?tab=studio 直接打开编辑器，/?tab=market 直接打开市场
  const tabParam = new URLSearchParams(location.search).get('tab');
  if (tabParam === 'studio') {
    document.querySelector('.tab[data-tab="stage-studio"]').click();
  } else if (tabParam === 'market') {
    document.querySelector('.tab[data-tab="stage-market"]').click();
  }
  renderEffects(META.effects);
  try {
    syncControls(await api('/api/state'));
  } catch (err) { /* 服务还没起来就下次轮询再同步 */ }

  makeSwatches('swatches', SWATCHES, (hex) => {
    $('colorPicker').value = hex;
    currentColor = hexToRgb(hex);
    api('/api/params', { color: currentColor });
  });
  makeSwatches('bgSwatches', BG_SWATCHES, (hex) => {
    $('bgPicker').value = hex;
    api('/api/params', { bg: hexToRgb(hex) });
  });

  $('colorPicker').addEventListener('input', (ev) => {
    currentColor = hexToRgb(ev.target.value);
    api('/api/params', { color: currentColor });
  });

  $('bgPicker').addEventListener('input', (ev) => {
    api('/api/params', { bg: hexToRgb(ev.target.value) });
  });

  $('bgLevel').addEventListener('input', () => {
    const v = Number($('bgLevel').value);
    $('bgLevelVal').textContent = v + '%';
    clearTimeout(bgTimer);
    bgTimer = setTimeout(() => api('/api/params', { bg_level: v / 100 }), 80);
  });

  let paramTimer = null;
  const pushParams = () => {
    clearTimeout(paramTimer);
    paramTimer = setTimeout(() => {
      api('/api/params', {
        brightness: Number($('brightness').value) / 100,
        speed: Number($('speed').value) / 100,
      });
    }, 90);
  };
  $('brightness').addEventListener('input', () => {
    $('brightnessVal').textContent = $('brightness').value + '%';
    pushParams();
  });
  $('speed').addEventListener('input', () => {
    $('speedVal').textContent = (Number($('speed').value) / 100).toFixed(1) + 'x';
    pushParams();
  });
  // 三个滑块都要在拖动期间锁住回填：否则拖到 0 会被下一帧的旧值弹回去，
  // 表现就是「背光拉到底还是亮的」。change 负责松手/键盘调整后的解锁。
  const setDrag = (which, on) => {
    if (which === 'brightness') brightnessDragging = on;
    else if (which === 'speed') speedDragging = on;
    else bgDragging = on;
  };
  ['brightness', 'speed', 'bgLevel'].forEach((id) => {
    const which = id === 'bgLevel' ? 'bg' : id;
    $(id).addEventListener('pointerdown', () => setDrag(which, true));
    $(id).addEventListener('input', () => setDrag(which, true));
    $(id).addEventListener('change', () => setDrag(which, false));
  });
  window.addEventListener('pointerup', () => {
    brightnessDragging = speedDragging = bgDragging = false;
  });

  $('fpsRange').addEventListener('pointerdown', () => { fpsDragging = true; });
  window.addEventListener('pointerup', () => { fpsDragging = false; });
  $('fpsRange').addEventListener('input', () => {
    fpsDragging = true;
    const v = Number($('fpsRange').value);
    setFpsLabel(v, null);
    clearTimeout(fpsTimer);
    fpsTimer = setTimeout(() => api('/api/params', { fps: v }), 60);
  });
  document.querySelectorAll('[data-fps]').forEach((btn) => {
    btn.addEventListener('click', () => applyFps(btn.dataset.fps));
  });

  $('paintMode').addEventListener('change', (ev) => {
    paintMode = ev.target.checked;
    $('keyboard').classList.toggle('painting', paintMode);
    api('/api/paint', { mode: paintMode });
  });
  $('clearPaint').addEventListener('click', () => api('/api/paint', { clear: true }));
  $('savePaint').addEventListener('click', savePaint);

  $('keepOnExit').addEventListener('change', async (ev) => {
    const want = ev.target.checked;
    const res = await api('/api/settings', { keep_on_exit: want });
    if (res.ok) {
      $('hint').textContent = want
        ? '已设置：关闭程序后保留键盘最后画面'
        : '已设置：关闭程序时恢复原厂灯效';
    }
  });
  $('autostart').addEventListener('change', async (ev) => {
    const want = ev.target.checked;
    const res = await api('/api/settings', { autostart: want });
    const actual = res.autostart != null ? res.autostart : want;
    ev.target.checked = actual;
    $('hint').textContent = actual
      ? '已加入开机启动：登录后自动在后台运行'
      : '已取消开机启动';
  });
  loadSettings();

  $('openFolder').addEventListener('click', async () => {
    const res = await api('/api/openfolder', {});
    $('hint').textContent = res.ok ? '已打开插件目录：' + res.path : '打开目录失败，路径见 README。';
  });

  $('checkPlugins').addEventListener('click', async () => {
    const box = $('checkOut');
    box.hidden = false;
    box.textContent = '检查中…';
    const res = await api('/api/checkplugins', {});
    if (!res.results || !res.results.length) {
      box.textContent = '没找到插件（effects_custom 里没有 .py）';
      return;
    }
    box.textContent = res.results.map((r) => {
      const mark = r.ok ? '✓' : '✗';
      let line = `${mark} ${r.file}  [${r.label}]  ${r.avg_ms}ms / 最差 ${r.worst_ms}ms`;
      if (r.message) line += `\n    ${r.message}`;
      return line;
    }).join('\n');
  });

  $('reload').addEventListener('click', async () => {
    const res = await api('/api/reload', {});
    renderEffects(res.effects);
    $('hint').textContent = '插件已重新加载：' + (res.loaded.length ? res.loaded.join('、') : '没有找到插件');
  });

  $('selftest').addEventListener('click', () => api('/api/test', {}));

  // ---------- 键位探针 ----------
  function updateProbeBar() {
    const bar = $('probeBar');
    const s = probeState;
    const on = probeMode && s;
    bar.hidden = !on;
    $('keyboard').classList.toggle('probing', !!on);
    if (!on) return;
    const done = s.key == null;
    $('probeKey').textContent = done ? '键位核对完成 🎉' : `正在核对：${s.label || '?'}`;
    $('probeInfo').textContent = done
      ? `全部 ${s.total} 个键位已核对，以后开机自动生效`
      : `实体键盘上亮红灯的是哪个键？点下面键盘图上同一个键（${s.confirmed}/${s.total}）`;
    $('probeOk').hidden = done;
    $('probeSkip').hidden = done;
  }

  async function probeAction(action, extra) {
    probeState = await api('/api/probe', Object.assign({ action }, extra || {}));
    probeMode = !!probeState.active;
    if (!probeMode && probeState.verified) {
      $('hint').textContent = '键位核对完成，已记住。';
    }
    updateProbeBar();
  }

  $('probeBtn').addEventListener('click', () => probeAction('start'));
  $('probeOk').addEventListener('click', () => probeAction('ok'));
  $('probeSkip').addEventListener('click', () => probeAction('skip'));
  $('probeStop').addEventListener('click', () => probeAction('stop'));
  $('probeReset').addEventListener('click', async () => {
    if (!window.confirm('清空这个机型的键位核对记录？下次需要重新核对。')) return;
    probeState = await api('/api/probe', { action: 'reset' });
    probeMode = false;
    updateProbeBar();
    $('hint').textContent = '核对记录已清空。';
  });
  window.addEventListener('keydown', (ev) => {
    if (!probeMode) return;
    if (ev.key === 'Escape') probeAction('stop');
    if (ev.key === ' ') { ev.preventDefault(); probeAction('ok'); }
  });

  $('diagBtn').addEventListener('click', async () => {
    const out = $('diagOut');
    out.hidden = false;
    out.textContent = '正在收集诊断信息…';
    try {
      const d = await api('/api/diagnostics');
      const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
      const blob = new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'AULA_LED_诊断_' + stamp + '.json';
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      const st = d.state || {};
      const lines = [
        '版本 ' + d.version + ' · ' + d.platform,
        '连接: ' + (st.connected ? '正常' : '未连接')
          + ' · 实际帧率 ' + (st.fps != null ? st.fps : '?')
          + ' · 发送失败 ' + (st.fails != null ? st.fails : '?') + ' 次',
        '当前效果: ' + (st.effect || '(无)') + (st.error ? ' · 错误: ' + st.error : ''),
        '本机识别的设备: ' + (d.bound_devices || []).map((x) => (
          typeof x === 'string' ? x
            : (x.product || '未知设备') + (x.interface != null ? ' [mi_' + x.interface + ']' : '')
        )).join(' | '),
        '在线 AULA 设备: ' + (d.hid_devices || []).map(x => x.vid + ':' + x.pid).join(', '),
        '',
        '✓ 完整报告已下载（AULA_LED_诊断_' + stamp + '.json），把它发给作者即可远程排查。',
      ];
      out.textContent = lines.join('\n');
    } catch (e) {
      out.textContent = '诊断失败: ' + e;
    }
  });

  $('quit').addEventListener('click', async () => {
    polling = false;
    await api('/api/quit', {});
    $('hint').textContent = '已退出，键盘灯光恢复到原生效果，可以直接关闭本页面。';
  });

  tick();
}


// ==================== 动画编辑器 ====================
// 数据：S.frames = [ {'43': [r,g,b], ...}, ... ]，没出现的键就是黑。
const S = {
  frames: [{}],
  index: 0,
  fps: 8,
  smooth: true,
  playing: false,
  brush: [41, 211, 255],
  eraser: false,
  els: new Map(),
  history: [],
  holdTimer: null,
  painting: false,
  strokeSnapshot: false,
};

let COORDS = {};

const THUMB_W = 132;
const THUMB_H = 50;
const THUMB_SX = 7.0;
const THUMB_SY = 9.6;

function buildCoords(layout) {
  COORDS = {};
  layout.forEach((row, r) => {
    let x = 0;
    row.forEach((k) => {
      COORDS[String(k.id)] = [x + k.w / 2, r];
      x += k.w + 0.12;
    });
  });
}

function buildStudioKeyboard(layout) {
  const kb = $('studioKeyboard');
  kb.innerHTML = '';
  S.els.clear();
  layout.forEach((row) => {
    const rowEl = document.createElement('div');
    rowEl.className = 'kb-row';
    row.forEach((key) => {
      const el = document.createElement('div');
      el.className = 'key' + (key.label.length > 3 ? ' small' : '');
      el.style.setProperty('--w', key.w);
      el.textContent = key.label;
      el.dataset.key = key.id;
      el.addEventListener('pointerdown', (ev) => {
        if (ev.button !== 0 || ev.isPrimary === false) return;
        ev.preventDefault();
        startStroke();
        strokeKey(key.id);
      });
      el.addEventListener('pointerenter', (ev) => {
        if (!S.painting || !(ev.buttons & 1)) return;
        strokeKey(key.id);
      });
      el.addEventListener('contextmenu', (ev) => {
        ev.preventDefault();
        endStroke();
        eraseKey(key.id);
      });
      rowEl.appendChild(el);
      S.els.set(String(key.id), el);
    });
    kb.appendChild(rowEl);
  });
}

function snapshot() {
  S.history.push(JSON.stringify(S.frames));
  if (S.history.length > 60) S.history.shift();
}

function startStroke() {
  S.painting = true;
  S.strokeSnapshot = false;
  const kb = $('studioKeyboard');
  if (kb) kb.classList.add('brushing');
}

function endStroke() {
  if (!S.painting) return;
  S.painting = false;
  S.strokeSnapshot = false;
  const kb = $('studioKeyboard');
  if (kb) kb.classList.remove('brushing');
}

// 拖动经过的每个键只改一次颜色；整段拖动只记一个撤销点。
function strokeKey(id) {
  const key = String(id);
  const frame = S.frames[S.index];
  if (S.eraser) {
    if (!(key in frame)) return;
    if (!S.strokeSnapshot) {
      snapshot();
      S.strokeSnapshot = true;
    }
    delete frame[key];
  } else {
    const rgb = S.brush;
    const old = frame[key];
    if (old && old[0] === rgb[0] && old[1] === rgb[1] && old[2] === rgb[2]) return;
    if (!S.strokeSnapshot) {
      snapshot();
      S.strokeSnapshot = true;
    }
    frame[key] = [rgb[0], rgb[1], rgb[2]];
  }
  afterEdit();
}

function paintKey(id, rgb) {
  snapshot();
  S.frames[S.index][String(id)] = [rgb[0], rgb[1], rgb[2]];
  afterEdit();
}

function eraseKey(id) {
  if (!(String(id) in S.frames[S.index])) return;
  snapshot();
  delete S.frames[S.index][String(id)];
  afterEdit();
}

function afterEdit() {
  paintStudioFrame();
  drawThumb(S.index);
  pushPreview();
}

function paintStudioFrame() {
  const frame = S.frames[S.index] || {};
  S.els.forEach((el, id) => applyColor(el, frame[id] || [0, 0, 0], false));
}

// ---------- 编辑器布局切换：连着 60 也能画 68 的动画 ----------
function buildLayoutSwitch() {
  const box = $('studioLayouts');
  if (!box) return;
  box.innerHTML = '';
  Object.keys(LAYOUTS).forEach((name) => {
    const title = (META.titles || {})[name] || name;
    const btn = document.createElement('button');
    btn.className = 'laybtn' + (name === S.layoutModel ? ' active' : '');
    btn.textContent = title.replace('WIN ', '').replace(' HE', '');
    btn.title = '按「' + title + '」的布局编辑';
    btn.addEventListener('click', () => switchStudioLayout(name));
    box.appendChild(btn);
  });
}

function switchStudioLayout(name) {
  if (!LAYOUTS[name] || name === S.layoutModel) return;
  S.layoutModel = name;
  buildStudioKeyboard(LAYOUTS[name]);
  buildCoords(LAYOUTS[name]);
  paintStudioFrame();
  renderTimeline();
  buildLayoutSwitch();
  $('studioHint').textContent =
    '已按「' + (META.titles || {})[name] + '」的布局编辑；播放时以实际连接的键盘为准，多余的键不会点亮';
  pushPreview();
}

// 把编辑结果同步到真实键盘：播放中用整段动画，编辑中用「停在当前帧」
function pushPreview() {
  clearTimeout(S.holdTimer);
  S.holdTimer = setTimeout(() => {
    if (S.playing) {
      api('/api/studio/play', { frames: S.frames, fps: S.fps, smooth: S.smooth });
    } else {
      api('/api/studio/hold', { frame: S.frames[S.index] || {} });
    }
  }, 90);
}

let timelineDragFrom = -1;
let timelineJustDragged = false;

function timelineDropIndex(box, clientX) {
  const thumbs = [...box.querySelectorAll('.thumb')];
  for (let i = 0; i < thumbs.length; i++) {
    const rect = thumbs[i].getBoundingClientRect();
    if (clientX < rect.left + rect.width / 2) return i;
  }
  return thumbs.length;
}

function clearTimelineDrag(box) {
  box.querySelectorAll('.thumb').forEach((el) => {
    el.classList.remove('dragging', 'drop-target');
  });
}

function renderTimeline() {
  const box = $('timeline');
  box.innerHTML = '';
  S.frames.forEach((frame, i) => {
    const wrap = document.createElement('div');
    wrap.className = 'thumb' + (i === S.index ? ' active' : '');
    wrap.draggable = true;
    const canvas = document.createElement('canvas');
    canvas.width = THUMB_W;
    canvas.height = THUMB_H;
    wrap.appendChild(canvas);
    const label = document.createElement('span');
    label.className = 'idx';
    label.textContent = i + 1;
    wrap.appendChild(label);
    wrap.addEventListener('click', () => {
      if (timelineJustDragged) return;
      selectFrame(i);
    });
    wrap.addEventListener('dragstart', (ev) => {
      timelineDragFrom = i;
      timelineJustDragged = false;
      wrap.classList.add('dragging');
      if (ev.dataTransfer) {
        ev.dataTransfer.effectAllowed = 'move';
        ev.dataTransfer.setData('text/plain', String(i));
      }
    });
    wrap.addEventListener('dragend', () => {
      const wasDragging = timelineDragFrom === i;
      timelineDragFrom = -1;
      clearTimelineDrag(box);
      if (wasDragging) timelineJustDragged = false;
    });
    box.appendChild(wrap);
    drawThumb(i, canvas);
  });

  box.ondragover = (ev) => {
    if (timelineDragFrom < 0) return;
    ev.preventDefault();
    if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'move';
    box.querySelectorAll('.thumb').forEach((el) => el.classList.remove('drop-target'));
    const idx = timelineDropIndex(box, ev.clientX);
    const thumbs = box.querySelectorAll('.thumb');
    const target = thumbs[Math.min(idx, thumbs.length - 1)];
    if (target) target.classList.add('drop-target');
  };
  box.ondrop = (ev) => {
    if (timelineDragFrom < 0) return;
    ev.preventDefault();
    const from = timelineDragFrom;
    let to = timelineDropIndex(box, ev.clientX);
    if (to > from) to -= 1;
    timelineDragFrom = -1;
    clearTimelineDrag(box);
    if (from < 0 || to < 0 || to >= S.frames.length || to === from) return;
    S.history.push(JSON.stringify(S.frames));
    if (S.history.length > 60) S.history.shift();
    const moved = S.frames.splice(from, 1)[0];
    S.frames.splice(to, 0, moved);
    S.index = to;
    timelineJustDragged = true;
    renderTimeline();
    paintStudioFrame();
    pushPreview();
    setTimeout(() => { timelineJustDragged = false; }, 0);
  };
  box.ondragleave = (ev) => {
    if (!box.contains(ev.relatedTarget)) clearTimelineDrag(box);
  };

  $('tlInfo').textContent = `第 ${S.index + 1} / ${S.frames.length} 帧`;
  $('tlWarn').textContent = S.frames.length > 120 ? '帧数偏多，建议精简' : '';
}

function drawThumb(i, canvas) {
  const c = canvas || document.querySelectorAll('#timeline canvas')[i];
  if (!c) return;
  const g = c.getContext('2d');
  g.fillStyle = '#070a11';
  g.fillRect(0, 0, c.width, c.height);
  const frame = S.frames[i] || {};
  Object.entries(frame).forEach(([id, rgb]) => {
    const pos = COORDS[id];
    if (!pos) return;
    g.fillStyle = `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;
    g.fillRect(pos[0] * THUMB_SX - 2.4, pos[1] * THUMB_SY + 2, 4.8, 6.4);
  });
}

function selectFrame(i) {
  const next = Math.max(0, Math.min(S.frames.length - 1, i));
  if (next === S.index) {
    paintStudioFrame();
    return;
  }
  S.index = next;
  document.querySelectorAll('.thumb').forEach((el, n) => {
    el.classList.toggle('active', n === S.index);
  });
  $('tlInfo').textContent = `第 ${S.index + 1} / ${S.frames.length} 帧`;
  paintStudioFrame();
  pushPreview();
}

function addFrame(copy) {
  snapshot();
  const base = copy ? JSON.parse(JSON.stringify(S.frames[S.index] || {})) : {};
  S.frames.splice(S.index + 1, 0, base);
  S.index += 1;
  renderTimeline();
  paintStudioFrame();
  pushPreview();
}

function removeFrame() {
  if (S.frames.length <= 1) {
    snapshot();
    S.frames = [{}];
    S.index = 0;
  } else {
    snapshot();
    S.frames.splice(S.index, 1);
    if (S.index >= S.frames.length) S.index = S.frames.length - 1;
  }
  renderTimeline();
  paintStudioFrame();
  pushPreview();
}

function undo() {
  if (!S.history.length) {
    $('studioHint').textContent = '没有可撤销的步骤了';
    return;
  }
  S.frames = JSON.parse(S.history.pop());
  if (!S.frames.length) S.frames = [{}];
  if (S.index >= S.frames.length) S.index = S.frames.length - 1;
  renderTimeline();
  paintStudioFrame();
  pushPreview();
}

async function grabFrame() {
  const s = await api('/api/state');
  snapshot();
  const frame = {};
  Object.entries(s.colors || {}).forEach(([id, rgb]) => {
    if (rgb[0] + rgb[1] + rgb[2] > 6) frame[id] = rgb;
  });
  S.frames[S.index] = frame;
  afterEdit();
  $('studioHint').textContent = '已把键盘当前的画面抓成一帧，继续在这上面画';
}

async function playStudio() {
  await api('/api/studio/play', { frames: S.frames, fps: S.fps, smooth: S.smooth });
  S.playing = true;
  $('playBtn').textContent = '正在播放…';
  $('playBtn').classList.add('on');
}

async function stopStudio() {
  await api('/api/studio/exit', {});
  S.playing = false;
  $('playBtn').textContent = '播放';
  $('playBtn').classList.remove('on');
  paintStudioFrame();
}

// ---------- 逐键绘制保存：把当前手绘存成一帧动画项目 ----------
async function savePaint() {
  const hint = $('paintHint');
  const say = (msg, ok) => {
    hint.textContent = msg;
    hint.hidden = false;
    hint.style.color = ok ? 'var(--ok, #7ee787)' : 'var(--warn, #f0883e)';
  };
  const s = await api('/api/state');
  const paint = {};
  Object.entries(s.paint || {}).forEach(([id, rgb]) => {
    if (rgb && (rgb[0] || rgb[1] || rgb[2])) paint[id] = [rgb[0], rgb[1], rgb[2]];
  });
  if (!Object.keys(paint).length) {
    say('键盘上还没有手绘内容，先开「逐键绘制」画几笔再保存');
    return;
  }
  const name = (prompt('给这幅手绘灯光起个名字：', '手绘灯光') || '').trim();
  if (!name) return;
  const res = await api('/api/studio/save', {
    name, fps: 8, smooth: false,
    frames: [paint],
    layout: META.model_name || Object.keys(LAYOUTS)[0],
  });
  if (!res.ok) {
    say('保存失败：' + (res.error || '未知原因'));
    return;
  }
  renderEffects(res.effects);
  await loadProjects(res.project.file);
  // 保存成功后自动退出涂鸦模式，避免继续盖住刚存的画面
  if ($('paintMode').checked) {
    $('paintMode').checked = false;
    paintMode = false;
    $('keyboard').classList.remove('painting');
    api('/api/paint', { mode: false });
  }
  say(`已保存「${res.project.name}」到效果列表，点它即可亮起来`);
}

async function saveStudio() {
  const name = ($('projName').value || '').trim();
  if (!name) {
    $('studioHint').textContent = '先给动画起个名字，再保存';
    $('projName').focus();
    return;
  }
  const res = await api('/api/studio/save', { name, fps: S.fps, smooth: S.smooth, frames: S.frames, layout: S.layoutModel });
  if (!res.ok) {
    $('studioHint').textContent = '保存失败：' + (res.error || '未知原因');
    return;
  }
  renderEffects(res.effects);
  await loadProjects(res.project.file);
  $('studioHint').textContent = `已保存「${res.project.name}」，生成 ${res.project.plugin}，效果列表里可直接点`;
}

async function loadProjects(selectFile) {
  const res = await api('/api/studio');
  const sel = $('projList');
  sel.innerHTML = '';
  const list = res.projects || [];
  if (!list.length) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = '（还没有保存过项目）';
    sel.appendChild(opt);
    return;
  }
  list.forEach((p) => {
    const lay = p.layout ? ` · ${(META.titles || {})[p.layout] || p.layout}` : '';
    const opt = document.createElement('option');
    opt.value = p.file;
    opt.textContent = `${p.name}（${p.frames} 帧 · ${p.fps} fps${lay}）`;
    sel.appendChild(opt);
  });
  if (selectFile) sel.value = selectFile;
}

async function loadProject() {
  const file = $('projList').value;
  if (!file) return;
  const res = await api('/api/studio/load', { file });
  if (!res.ok) {
    $('studioHint').textContent = '加载失败：' + (res.error || '未知原因');
    return;
  }
  const p = res.project;
  S.frames = (p.frames && p.frames.length) ? p.frames : [{}];
  // 旧工程可能残留反馈配置用的 -1 / -2 隐藏键，加载时清掉
  S.frames.forEach((f) => { if (f) { delete f['-1']; delete f['-2']; } });
  S.index = 0;
  S.fps = Math.max(1, Math.min(24, Math.round(p.fps || 8)));
  S.smooth = !!p.smooth;
  S.history = [];
  if (p.layout && LAYOUTS[p.layout]) {
    S.layoutModel = p.layout;
    buildStudioKeyboard(LAYOUTS[p.layout]);
    buildCoords(LAYOUTS[p.layout]);
    buildLayoutSwitch();
  }
  $('sfps').value = S.fps;
  $('sfpsVal').textContent = S.fps + ' 帧/秒';
  $('smooth').checked = S.smooth;
  $('projName').value = p.name;
  renderTimeline();
  paintStudioFrame();
  pushPreview();
  $('studioHint').textContent = `已加载「${p.name}」`;
}

async function deleteProject() {
  const file = $('projList').value;
  if (!file) return;
  if (!window.confirm('删除这个项目？同时会删掉它生成的插件。')) return;
  const res = await api('/api/studio/delete', { file });
  if (res.effects) renderEffects(res.effects);
  await loadProjects();
  $('studioHint').textContent = '项目已删除';
}

function moveTabIndicator(btn) {
  const bar = $('tabsBar');
  const indicator = $('tabIndicator');
  if (!bar || !indicator || !btn) return;
  const barRect = bar.getBoundingClientRect();
  const btnRect = btn.getBoundingClientRect();
  indicator.style.width = btnRect.width + 'px';
  indicator.style.transform = 'translateX(' + (btnRect.left - barRect.left) + 'px)';
}

function bindStudio() {
  document.querySelectorAll('.tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('active', b === btn));
      moveTabIndicator(btn);
      $('stage-panel').hidden = tab !== 'stage-panel';
      $('stage-studio').hidden = tab !== 'stage-studio';
      $('stage-market').hidden = tab !== 'stage-market';
      // 进入编辑器时先把当前帧推到键盘，做到所见即所改
      if (tab === 'stage-studio' && !S.playing) pushPreview();
      // 离开编辑器就退出预览，把键盘还给灯光控制/市场
      if (tab !== 'stage-studio' && S.studio) {
        S.playing = false;
        api('/api/studio/exit', {});
      }
      if (tab === 'stage-market') loadMarket(false);
    });
  });
  requestAnimationFrame(() => {
    moveTabIndicator(document.querySelector('.tab.active'));
  });
  window.addEventListener('resize', () => {
    moveTabIndicator(document.querySelector('.tab.active'));
  });

  // 鼠标拖出窗口/松开在窗口外时也要结束笔画，避免下次移动误上色。
  window.addEventListener('pointerup', endStroke);
  window.addEventListener('pointercancel', endStroke);
  window.addEventListener('blur', endStroke);
  window.addEventListener('pointermove', (ev) => {
    if (S.painting && !(ev.buttons & 1)) endStroke();
  });

  makeSwatches('brushSwatches', SWATCHES, pickBrush);
  renderBrushSwatches();
  $('brush').addEventListener('input', (ev) => {
    S.brush = hexToRgb(ev.target.value);
  });
  $('eraser').addEventListener('click', () => {
    S.eraser = !S.eraser;
    $('eraser').classList.toggle('on', S.eraser);
    $('studioKeyboard').style.cursor = S.eraser ? 'not-allowed' : '';
  });
  $('fillAll').addEventListener('click', () => {
    snapshot();
    const frame = S.frames[S.index];
    Object.keys(COORDS).forEach((id) => {
      frame[id] = [S.brush[0], S.brush[1], S.brush[2]];
    });
    afterEdit();
  });
  $('grabFrame').addEventListener('click', grabFrame);
  $('undo').addEventListener('click', undo);

  $('sfps').addEventListener('input', () => {
    S.fps = Number($('sfps').value);
    $('sfpsVal').textContent = S.fps + ' 帧/秒';
    if (S.playing) pushPreview();
  });
  $('smooth').addEventListener('change', (ev) => {
    S.smooth = ev.target.checked;
    if (S.playing) pushPreview();
  });

  $('playBtn').addEventListener('click', playStudio);
  $('stopBtn').addEventListener('click', stopStudio);
  $('prevFrame').addEventListener('click', () => selectFrame(S.index - 1));
  $('nextFrame').addEventListener('click', () => selectFrame(S.index + 1));
  $('addFrame').addEventListener('click', () => addFrame(false));
  $('dupFrame').addEventListener('click', () => addFrame(true));
  $('clearFrame').addEventListener('click', () => {
    snapshot();
    S.frames[S.index] = {};
    afterEdit();
  });
  $('delFrame').addEventListener('click', removeFrame);

  $('saveBtn').addEventListener('click', saveStudio);
  $('loadBtn').addEventListener('click', loadProject);
  $('delProj').addEventListener('click', deleteProject);
}

// ==================== 独立窗口刷新 ====================
function initAppRefresh() {
  const btn = $('appRefresh');
  if (!btn) return;
  btn.addEventListener('click', () => {
    const active = document.querySelector('.tab.active');
    const tab = active ? active.dataset.tab : '';
    const params = new URLSearchParams();
    if (tab === 'stage-studio') params.set('tab', 'studio');
    else if (tab === 'stage-market') params.set('tab', 'market');
    params.set('_', Date.now().toString());
    btn.disabled = true;
    location.href = location.pathname + '?' + params.toString();
  });
}

// ==================== 用系统浏览器打开控制台 ====================
function initOpenBrowser() {
  const btn = $('openBrowser');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    try {
      await api('/api/open-browser');
      $('hint').textContent = '已用系统浏览器打开控制台：http://127.0.0.1:8720/';
    } catch (err) {
      // 旧版本后端没有这个接口时，退回普通新窗口
      window.open('http://127.0.0.1:8720/', '_blank');
    }
  });
}

// ==================== 上传到市场（自动创建 PR） ====================
const MARKET_REPO = { owner: 'lovenacho', repo: 'aula-led-market' };

function uploadStatus(text, error, tone) {
  const el = $('upStatus');
  if (!el) return;
  el.textContent = text;
  el.classList.toggle('is-error', !!error);
  el.classList.toggle('is-ok', !error && tone === 'ok');
  el.style.color = error ? 'var(--warn, #f0883e)'
    : (tone === 'ok' ? 'var(--ok, #7ee787)' : 'var(--muted)');
}

function bytesToBase64(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function utf8ToBase64(text) {
  return bytesToBase64(new TextEncoder().encode(text));
}

function base64ToText(value) {
  const binary = atob(String(value || '').replace(/\s+/g, ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

async function sha256Hex(bytes) {
  if (!window.crypto || !crypto.subtle) throw new Error('当前环境不支持 SHA-256');
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function githubApi(path, options, token) {
  const res = await fetch('https://api.github.com' + path, {
    ...(options || {}),
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: 'Bearer ' + token,
      'X-GitHub-Api-Version': '2022-11-28',
      'Content-Type': 'application/json',
      ...((options && options.headers) || {}),
    },
  });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (err) { data = null; }
  if (!res.ok) {
    const message = (data && data.message) || ('GitHub API HTTP ' + res.status);
    if (res.status === 401) throw new Error('Token 无效或已过期：' + message);
    if (res.status === 403) throw new Error('Token 没有仓库写权限：' + message);
    if (res.status === 404) throw new Error('仓库/路径不存在，或 Token 没有该仓库权限：' + message);
    throw new Error(message);
  }
  return data;
}

function drawUploadPreview(layout, frame) {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 320;
    const g = canvas.getContext('2d');
    const unit = 34;
    const keyH = 40;
    const gap = 5;
    g.fillStyle = '#080c18';
    g.fillRect(0, 0, 640, 320);
    const totalH = layout.length * (keyH + gap) - gap;
    const gridTop = 38 + Math.max(0, (320 - 76 - totalH) / 2);
    const rounded = (x, y, w, h, r) => {
      g.beginPath();
      g.moveTo(x + r, y);
      g.arcTo(x + w, y, x + w, y + h, r);
      g.arcTo(x + w, y + h, x, y + h, r);
      g.arcTo(x, y + h, x, y, r);
      g.arcTo(x, y, x + w, y, r);
      g.closePath();
    };
    rounded(18, gridTop - 16, 604, totalH + 32, 16);
    g.fillStyle = '#0d1222';
    g.fill();
    g.strokeStyle = '#26304a';
    g.stroke();
    layout.forEach((row, rowIndex) => {
      const rowW = row.reduce((sum, key) => sum + unit * key.w, 0) + gap * (row.length - 1);
      let x = (640 - rowW) / 2;
      const y = gridTop + rowIndex * (keyH + gap);
      row.forEach((key) => {
        const w = unit * key.w - gap;
        const color = (frame && frame[String(key.id)]) || [26, 32, 48];
        rounded(x, y, w, keyH, 5);
        g.fillStyle = 'rgb(' + color[0] + ',' + color[1] + ',' + color[2] + ')';
        g.fill();
        g.strokeStyle = '#3a4866';
        g.stroke();
        const label = String(key.label);
        const fontSize = label.length <= 4 ? 11 : 9;
        g.font = fontSize + 'px Arial, sans-serif';
        g.textAlign = 'center';
        g.textBaseline = 'middle';
        const lum = (0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2]) / 255;
        g.fillStyle = lum > 0.55 ? '#0a0e16' : '#aab8cd';
        g.fillText(label, x + w / 2, y + keyH / 2, w - 4);
        x += unit * key.w + gap;
      });
    });
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('预览图生成失败'));
    }, 'image/png');
  });
}

async function uploadAnimationToMarket() {
  const token = await unlockTokenForUpload();
  const name = ($('upName').value || '').trim();
  const author = ($('upAuthor').value || '').trim() || '那秋眠';
  const license = ($('upLicense').value || '').trim() || 'CC-BY-4.0';
  const description = ($('upDesc').value || '').trim();
  if (!token) throw new Error('请填写 GitHub Token');
  if (!name) throw new Error('请填写动画名');
  const use60 = $('upModel60').checked;
  const use68 = $('upModel68').checked;
  if (!use60 && !use68) throw new Error('至少选择一个适配型号');
  if (!S.frames.length) throw new Error('当前没有可上传的帧');

  const models = [];
  const layouts = [];
  if (use60) {
    models.push('60键');
    layouts.push('win60he', 'win60hepro', 'win60hemax', 'win60se');
  }
  if (use68) {
    models.push('68键');
    layouts.push('win68he');
  }
  const layoutName = use68 && !use60 ? 'win68he' : (META.model_name || S.layoutModel || 'win60he');
  const layout = LAYOUTS[layoutName] || META.layout;
  const previewBlob = await drawUploadPreview(layout, S.frames[Math.floor(S.frames.length / 2)] || {});
  const previewBytes = new Uint8Array(await previewBlob.arrayBuffer());

  const id = 'anim-' + name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') +
    '-' + Date.now().toString(36);
  const framesText = JSON.stringify({
    name, fps: S.fps, smooth: S.smooth, frames: S.frames,
    updated: new Date().toISOString().slice(0, 19).replace('T', ' '),
    layout: layoutName,
  }, null, 2) + '\n';
  const framesBytes = new TextEncoder().encode(framesText);
  const framesSha = await sha256Hex(framesBytes);
  const framesPath = 'animations/' + id + '/frames.json';
  const previewPath = 'previews/' + id + '.png';
  const manifest = {
    id, name, author, version: '1.0.0', license,
    min_app: 'v2.4.4', description, models, layouts,
    fps: S.fps, smooth: S.smooth, tags: [],
    preview: previewPath, frames: framesPath,
  };
  const manifestText = JSON.stringify(manifest, null, 2) + '\n';

  const repoPath = MARKET_REPO.owner + '/' + MARKET_REPO.repo;
  uploadStatus('读取 GitHub 仓库…');
  const ref = await githubApi('/repos/' + repoPath + '/git/ref/heads/main', { method: 'GET' }, token);
  const indexRes = await githubApi('/repos/' + repoPath + '/contents/index.json', { method: 'GET' }, token);
  const index = JSON.parse(base64ToText(indexRes.content));
  if (!Array.isArray(index.animations)) throw new Error('仓库 index.json 格式不对');
  const sameName = index.animations.filter((a) => a.name === name);
  if (sameName.length) {
    const ids = sameName.map((a) => a.id).join('、');
    if (!confirm('市场里已经有同名动画：' + ids + '\n继续上传会产生第二个「' + name + '」，确定吗？')) {
      uploadStatus('已取消：市场已有同名动画 ' + ids);
      return;
    }
  }
  const branch = 'market-upload-' + id;
  uploadStatus('创建分支…');
  await githubApi('/repos/' + repoPath + '/git/refs', {
    method: 'POST',
    body: JSON.stringify({ ref: 'refs/heads/' + branch, sha: ref.object.sha }),
  }, token);

  const putFile = async (path, base64, message, sha) => {
    const payload = { message, content: base64, branch };
    if (sha) payload.sha = sha;
    const encoded = path.split('/').map(encodeURIComponent).join('/');
    await githubApi('/repos/' + repoPath + '/contents/' + encoded, {
      method: 'PUT', body: JSON.stringify(payload),
    }, token);
  };

  uploadStatus('上传动画文件…');
  await putFile('animations/' + id + '/manifest.json', utf8ToBase64(manifestText), 'market: add ' + name);
  await putFile(framesPath, bytesToBase64(framesBytes), 'market: add ' + name);
  await putFile(previewPath, bytesToBase64(previewBytes), 'market: add ' + name);

  index.animations.push({
    ...manifest,
    frames_url: framesPath,
    frames_count: S.frames.length,
    size: framesBytes.length,
    sha256: framesSha,
  });
  index.animations.sort((a, b) => String(a.id).localeCompare(String(b.id)));
  index.updated = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  uploadStatus('更新市场索引…');
  await putFile('index.json', utf8ToBase64(JSON.stringify(index, null, 2) + '\n'),
    'market: index for ' + name, indexRes.sha);

  uploadStatus('创建 Pull Request…');
  const pr = await githubApi('/repos/' + repoPath + '/pulls', {
    method: 'POST',
    body: JSON.stringify({
      title: '[market] ' + name,
      head: branch,
      base: 'main',
      body: '自动上传动画：' + name + '\n\n'
        + '- 作者：' + author + '\n'
        + '- 适配：' + models.join(' / ') + '\n'
        + '- 许可证：' + license + '\n'
        + '- 帧数：' + S.frames.length + ' @ ' + S.fps + 'fps\n\n'
        + '请审核预览、帧数据和许可证后合并。',
    }),
  }, token);
  uploadStatus('已提交 PR：' + pr.html_url + '\n管理员合并后，动画就会出现在市场里。', false, 'ok');
  window.open(pr.html_url, '_blank');
}

async function buildSubmissionPackage() {
  const name = ($('upName').value || '').trim();
  const author = ($('upAuthor').value || '').trim() || '匿名';
  const license = ($('upLicense').value || '').trim() || 'CC-BY-4.0';
  const description = ($('upDesc').value || '').trim();
  if (!name) throw new Error('请填写动画名');
  const use60 = $('upModel60').checked;
  const use68 = $('upModel68').checked;
  if (!use60 && !use68) throw new Error('至少选择一个适配型号');
  if (!S.frames.length) throw new Error('当前没有可导出的帧');

  const models = [];
  const layouts = [];
  if (use60) {
    models.push('60键');
    layouts.push('win60he', 'win60hepro', 'win60hemax', 'win60se');
  }
  if (use68) {
    models.push('68键');
    layouts.push('win68he');
  }
  const layoutName = use68 && !use60 ? 'win68he' : (META.model_name || S.layoutModel || 'win60he');
  const layout = LAYOUTS[layoutName] || META.layout;
  const previewBlob = await drawUploadPreview(layout, S.frames[Math.floor(S.frames.length / 2)] || {});
  const previewBytes = new Uint8Array(await previewBlob.arrayBuffer());
  const id = 'anim-' + name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') +
    '-' + Date.now().toString(36);
  const framesObj = {
    name, fps: S.fps, smooth: S.smooth, frames: S.frames,
    updated: new Date().toISOString().slice(0, 19).replace('T', ' '),
    layout: layoutName,
  };
  const manifest = {
    id, name, author, version: '1.0.0', license,
    min_app: 'v2.4.4', description, models, layouts,
    fps: S.fps, smooth: S.smooth, tags: [],
    preview: 'previews/' + id + '.png',
    frames: 'animations/' + id + '/frames.json',
  };
  const pack = {
    format: 'aula-led-market-submission',
    version: 1,
    manifest,
    frames: framesObj,
    preview_png_base64: bytesToBase64(previewBytes),
  };
  return { pack, id };
}

async function exportSubmissionPackage() {
  const { pack, id } = await buildSubmissionPackage();
  const blob = new Blob([JSON.stringify(pack, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = id + '.aulaanim.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  uploadStatus('已导出：' + id + '.aulaanim.json\n接着在打开的 GitHub 页面里，把文件拖进附件框，点 Submit new issue。', false, 'ok');
  window.open('https://github.com/lovenacho/aula-led-market/issues/new?template=submit-animation.yml', '_blank');
}

const MARKET_TOKEN_KEY = 'aulaMarketToken';
const MARKET_TOKEN_VAULT = 'aulaMarketTokenVault';
let marketTokenUnlocked = '';

function setTokenState(text, bad) {
  const el = $('upTokenState');
  if (!el) return;
  el.textContent = text;
  el.style.color = bad ? '#ff7b7b' : '';
}

function readTokenVault() {
  try {
    const raw = localStorage.getItem(MARKET_TOKEN_VAULT);
    return raw ? JSON.parse(raw) : null;
  } catch (err) { return null; }
}

function bytesToB64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

function b64ToBytes(text) {
  const s = atob(text);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

async function deriveTokenKey(pin, salt) {
  const enc = new TextEncoder();
  const base = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' },
    base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

async function encryptToken(token, pin) {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveTokenKey(pin, salt);
  const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(token));
  return { v: 1, salt: bytesToB64(salt), iv: bytesToB64(iv), data: bytesToB64(new Uint8Array(data)) };
}

async function decryptToken(vault, pin) {
  const key = await deriveTokenKey(pin, b64ToBytes(vault.salt));
  const data = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: b64ToBytes(vault.iv) }, key, b64ToBytes(vault.data));
  return new TextDecoder().decode(data);
}

function lockTokenInput() {
  const input = $('upToken');
  const save = $('upTokenSave');
  const vault = readTokenVault();
  if (!input) return;
  if (vault) {
    input.value = '';
    input.disabled = true;
    input.placeholder = '已加密保存（点「修改 Token」解锁）';
    if (save) save.textContent = '修改 Token';
    setTokenState('已加密保存，修改/上传需要 PIN');
  } else {
    input.disabled = false;
    input.placeholder = 'ghp_...（Classic Token）';
    if (save) save.textContent = '保存 Token';
    setTokenState('未保存');
  }
}

function loadSavedMarketToken() {
  const input = $('upToken');
  if (!input) return;
  lockTokenInput();
  if (!readTokenVault()) {
    try {
      const legacy = localStorage.getItem(MARKET_TOKEN_KEY) || '';
      if (legacy) {
        input.value = legacy;
        setTokenState('未加密保存，建议重新保存并设置 PIN');
      }
    } catch (err) { /* ignore */ }
  }
}

async function promptTokenPin(title) {
  const pin = window.prompt(title || '输入 Token PIN（4-8 位）', '');
  if (pin === null) return '';
  return pin.trim();
}

async function unlockTokenForUpload() {
  if (marketTokenUnlocked) return marketTokenUnlocked;
  const vault = readTokenVault();
  if (!vault) {
    const raw = ($('upToken').value || '').trim();
    if (!raw) throw new Error('Token 未就绪：请填写并保存 GitHub Token，或确认随包 Token 已载入');
    marketTokenUnlocked = raw;
    return raw;
  }
  const pin = await promptTokenPin('输入 PIN 解锁 Token');
  if (!pin) throw new Error('已取消解锁');
  try {
    const token = await decryptToken(vault, pin);
    marketTokenUnlocked = token;
    setTokenState('已解锁');
    return token;
  } catch (err) {
    throw new Error('PIN 错误或 Token 数据损坏');
  }
}

async function editMarketToken() {
  const vault = readTokenVault();
  if (!vault) return;
  const pin = await promptTokenPin('输入当前 PIN 以修改 Token');
  if (!pin) return;
  try {
    await decryptToken(vault, pin);
  } catch (err) {
    setTokenState('PIN 错误', true);
    return;
  }
  const input = $('upToken');
  input.disabled = false;
  input.value = '';
  input.placeholder = '输入新的 Classic Token';
  $('upTokenSave').textContent = '保存 Token';
  input.focus();
  setTokenState('已解锁，输入新 Token 后点保存');
}

async function saveMarketToken() {
  const input = $('upToken');
  const token = (input.value || '').trim();
  if (!token) {
    setTokenState('请先填写 Token', true);
    return;
  }
  const vault = readTokenVault();
  let pin = '';
  if (vault) {
    pin = await promptTokenPin('输入当前 PIN 后保存新 Token');
    if (!pin) return;
    try {
      await decryptToken(vault, pin);
    } catch (err) {
      setTokenState('PIN 错误', true);
      return;
    }
  } else {
    pin = await promptTokenPin('设置 Token PIN（4-8 位，修改和上传时需要）');
    if (!pin) return;
    if (pin.length < 4 || pin.length > 8) {
      setTokenState('PIN 需要 4-8 位', true);
      return;
    }
    const confirm = await promptTokenPin('再次输入 PIN');
    if (confirm !== pin) {
      setTokenState('两次 PIN 不一致', true);
      return;
    }
  }
  try {
    if (!crypto || !crypto.subtle) throw new Error('当前浏览器不支持加密');
    const data = await encryptToken(token, pin);
    localStorage.setItem(MARKET_TOKEN_VAULT, JSON.stringify(data));
    localStorage.removeItem(MARKET_TOKEN_KEY);
    marketTokenUnlocked = token;
    lockTokenInput();
    setTokenState('已加密保存，修改/上传需要 PIN');
    uploadStatus('Token 已加密保存在本机。');
  } catch (err) {
    setTokenState('保存失败：' + String(err.message || err), true);
  }
}

async function clearMarketToken() {
  const vault = readTokenVault();
  if (vault) {
    const pin = await promptTokenPin('输入 PIN 以清除 Token');
    if (!pin) return;
    try {
      await decryptToken(vault, pin);
    } catch (err) {
      setTokenState('PIN 错误，未清除', true);
      return;
    }
  }
  try {
    localStorage.removeItem(MARKET_TOKEN_VAULT);
    localStorage.removeItem(MARKET_TOKEN_KEY);
  } catch (err) { /* ignore */ }
  marketTokenUnlocked = '';
  const input = $('upToken');
  if (input) { input.value = ''; input.disabled = false; }
  lockTokenInput();
  setTokenState('已清除');
}

async function changeTokenPin() {
  const vault = readTokenVault();
  if (!vault) {
    setTokenState('请先保存 Token 再修改 PIN', true);
    return;
  }
  const oldPin = await promptTokenPin('输入当前 PIN');
  if (!oldPin) return;
  let token = '';
  try {
    token = await decryptToken(vault, oldPin);
  } catch (err) {
    setTokenState('PIN 错误', true);
    return;
  }
  let nextPin = await promptTokenPin('设置新 PIN（4-8 位）');
  if (!nextPin) return;
  if (nextPin.length < 4 || nextPin.length > 8) {
    setTokenState('PIN 需要 4-8 位', true);
    return;
  }
  const confirm = await promptTokenPin('再次输入新 PIN');
  if (confirm !== nextPin) {
    setTokenState('两次 PIN 不一致', true);
    return;
  }
  try {
    const data = await encryptToken(token, nextPin);
    localStorage.setItem(MARKET_TOKEN_VAULT, JSON.stringify(data));
    marketTokenUnlocked = token;
    lockTokenInput();
    setTokenState('PIN 已修改');
    uploadStatus('Token PIN 已更新，下次修改/上传使用新 PIN。');
  } catch (err) {
    setTokenState('修改失败：' + String(err.message || err), true);
  }
}

function exportPortableToken() {
  const vault = readTokenVault();
  if (!vault) {
    setTokenState('请先保存 Token 再导出', true);
    return;
  }
  const blob = new Blob([JSON.stringify(vault, null, 2) + '\n'], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'portable_token.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setTokenState('已导出，放到 _internal/web/ 后一起打包');
  uploadStatus('已导出 portable_token.json。把它放进 _internal/web/，发布包就会带上加密 Token；接收方仍需 PIN。');
}

async function loadPortableToken() {
  if (readTokenVault()) return false;
  try {
    const res = await fetch('portable_token.json', { cache: 'no-store' });
    if (!res.ok) return false;
    const data = await res.json();
    if (!data || data.v !== 1 || !data.salt || !data.iv || !data.data) return false;
    localStorage.setItem(MARKET_TOKEN_VAULT, JSON.stringify(data));
    return true;
  } catch (err) {
    return false;
  }
}

function initMarketUpload() {
  const btn = $('marketUploadBtn');
  if (!btn) return;
  const mask = $('uploadMask');
  loadSavedMarketToken();
  loadPortableToken().then((loaded) => {
    if (!loaded) return;
    marketTokenUnlocked = '';
    loadSavedMarketToken();
    setTokenState('已从发布包载入加密 Token，使用需 PIN');
  });
  $('upTokenPin').addEventListener('click', changeTokenPin);
  $('upTokenExport').addEventListener('click', exportPortableToken);
  $('upTokenSave').addEventListener('click', async () => {
    const input = $('upToken');
    if (readTokenVault() && input.disabled) {
      await editMarketToken();
    } else {
      await saveMarketToken();
    }
  });
  $('upTokenClear').addEventListener('click', clearMarketToken);
  $('upToken').addEventListener('input', () => {
    if ($('upToken').disabled) return;
    setTokenState('未保存', false);
  });
  $('marketUploadBtn').addEventListener('click', () => {
    mask.hidden = false;
    loadSavedMarketToken();
    if (!$('upName').value) $('upName').value = $('projName').value || '';
    uploadStatus('');
  });
  const close = () => { mask.hidden = true; };
  $('uploadClose').addEventListener('click', close);
  $('upCancel').addEventListener('click', close);
  mask.addEventListener('click', (ev) => { if (ev.target === mask) close(); });
  $('upSubmit').addEventListener('click', async () => {
    const submit = $('upSubmit');
    const label = submit.textContent;
    submit.disabled = true;
    submit.textContent = '上传中…';
    try {
      await uploadAnimationToMarket();
    } catch (err) {
      uploadStatus(String(err.message || err), true);
    } finally {
      submit.disabled = false;
      submit.textContent = label;
    }
  });
  $('upExport').addEventListener('click', async () => {
    const btn = $('upExport');
    btn.disabled = true;
    try {
      await exportSubmissionPackage();
    } catch (err) {
      uploadStatus(String(err.message || err), true);
    } finally {
      btn.disabled = false;
    }
  });
}

// ==================== 动画市场（原型） ====================
function escapeMarketHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function marketIndexUrl() {
  if (!MARKET_BASE_URL) return null;
  try {
    return new URL(MARKET_BASE_URL);
  } catch (err) {
    return null;
  }
}

function marketAssetUrl(path) {
  const base = marketIndexUrl();
  if (!base || !path) return '';
  try {
    const url = new URL(path, base.href);
    return /^https?:$/.test(url.protocol) ? url.href : '';
  } catch (err) {
    return '';
  }
}

async function refreshMarketInstalled() {
  try {
    const res = await api('/api/studio');
    MARKET_INSTALLED = new Set((res.projects || []).map((p) => p.name));
  } catch (err) {
    // 市场列表仍可用；安装按钮会按“未安装”显示
  }
}

function renderMarket() {
  const grid = $('marketGrid');
  if (!grid || !MARKET) return;
  const keyword = ($('marketSearch').value || '').trim().toLowerCase();
  const list = (MARKET.animations || []).filter((a) => {
    if (!keyword) return true;
    const text = [a.name, a.author, (a.tags || []).join(' ')].join(' ').toLowerCase();
    return text.includes(keyword);
  });
  if (!list.length) {
    grid.innerHTML = '<div class="market-empty">没有找到匹配的动画。</div>';
    return;
  }
  grid.innerHTML = list.map((a) => {
    const previewBase = marketAssetUrl(a.preview);
    const preview = previewBase
      ? previewBase + (previewBase.includes('?') ? '&' : '?') + 'v=' + encodeURIComponent(MARKET.updated || '1')
      : '';
    const installed = MARKET_INSTALLED.has(a.name);
    const meta = [
      a.author || '未知作者',
      (a.frames_count || '?') + ' 帧',
      (a.fps || '?') + ' fps',
      a.size ? Math.max(1, Math.round(a.size / 1024)) + ' KB' : '',
    ].filter(Boolean).join(' · ');
    const modelLabels = {
      win60he: '60键', win60se: '60键 SE', win60hepro: '60键 PRO',
      win60hemax: '60键 MAX', win68he: '68键',
    };
    const modelText = (a.models && a.models.length)
      ? a.models.join(' / ')
      : (a.layouts || []).map((x) => modelLabels[x] || x).join(' / ');
    return `<div class="market-item">
      ${preview ? `<img src="${escapeMarketHtml(preview)}" alt="" loading="lazy">` : ''}
      <div class="mbody">
        <h4>${escapeMarketHtml(a.name || a.id)} <span>v${escapeMarketHtml(a.version || '1.0.0')}</span></h4>
        <div class="mmeta">ID：${escapeMarketHtml(a.id)}</div>
        <div class="mmeta">${escapeMarketHtml(meta)}</div>
        <div class="mmeta">适配：${escapeMarketHtml(modelText || '未知')}</div>
        <p class="mdesc">${escapeMarketHtml(a.description || '')}</p>
        <div class="mmeta">${escapeMarketHtml((a.tags || []).join(' / '))}${installed ? ' · <span class="market-badge">已安装</span>' : ''}</div>
        <div class="mrow">
          <button class="btn ${installed ? 'ghost' : ''}" data-market-action="install" data-market-id="${escapeMarketHtml(a.id)}">${installed ? '重新安装' : '安装'}</button>
          ${installed ? `<button class="btn danger" data-market-action="uninstall" data-market-id="${escapeMarketHtml(a.id)}">卸载</button>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

async function fetchMarketJson(url, timeoutMs) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs || 5000);
  try {
    const res = await fetch(url, { cache: 'no-store', signal: ctrl.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

function setMarketSource(text, cls) {
  const el = $('marketSource');
  if (!el) return;
  el.textContent = text;
  el.className = 'market-source ' + (cls || '');
}

async function fetchGitHubApiIndex() {
  const res = await fetch(
    'https://api.github.com/repos/lovenacho/aula-led-market/contents/index.json?ref=main',
    { cache: 'no-store' },
  );
  if (!res.ok) throw new Error('GitHub API HTTP ' + res.status);
  const file = await res.json();
  const data = JSON.parse(base64ToText(file.content));
  if (!data || !Array.isArray(data.animations)) throw new Error('GitHub API index 格式不对');
  return {
    source: 'github-api',
    base: 'https://raw.githubusercontent.com/lovenacho/aula-led-market/main/',
    data,
  };
}

async function loadMarket(force) {
  if (marketLoading) return;
  if (MARKET && !force) {
    await refreshMarketInstalled();
    renderMarket();
    return;
  }
  marketLoading = true;
  $('marketStatus').textContent = '加载中…';
  setMarketSource('来源：检测中…', '');
  let lastError = null;
  try {
    const loadOne = async (source) => {
      const base = new URL(source, location.href);
      const url = new URL(base.href);
      url.searchParams.set('_', Date.now());
      const data = await fetchMarketJson(url.href, 5000);
      if (!data || !Array.isArray(data.animations)) throw new Error('index.json 格式不对');
      return { source, base: base.href, data };
    };

    const remotes = MARKET_INDEX_URLS.filter((source) => source !== MARKET_LOCAL_URL);
    // GitHub API 读 index 不受 raw/jsDelivr 缓存影响，是首选。
    let chosen = await Promise.race([
      fetchGitHubApiIndex().catch(() => null),
      new Promise((resolve) => setTimeout(() => resolve(null), 2500)),
    ]);
    if (!chosen && remotes.length) {
      const rawSource = remotes.find((source) => source.includes('raw.githubusercontent.com'))
        || remotes[0];
      const others = remotes.filter((source) => source !== rawSource);
      // raw.githubusercontent.com 是当前提交，优先等它 1.5 秒；
      // CDN 可能还缓存着旧的 index，不能让它先抢到。
      const rawPromise = loadOne(rawSource).catch(() => null);
      const othersPromise = others.length
        ? Promise.any(others.map(loadOne)).catch(() => null)
        : Promise.resolve(null);
      const raw = await Promise.race([
        rawPromise,
        new Promise((resolve) => setTimeout(() => resolve(null), 1500)),
      ]);
      chosen = raw || await othersPromise;
      if (!chosen) lastError = new Error('远程市场不可用');
    }
    const isLocal = !chosen;
    if (!chosen) {
      chosen = await loadOne(MARKET_LOCAL_URL);
    }
    MARKET_BASE_URL = chosen.base;
    MARKET = chosen.data;
    await refreshMarketInstalled();
    $('marketStatus').textContent = isLocal
      ? `${chosen.data.animations.length} 个动画 · 本地示例（远程不可用）`
      : `${chosen.data.animations.length} 个动画`;
    setMarketSource(isLocal ? '来源：本地示例（远程不可用）' : '来源：GitHub / CDN',
                    isLocal ? 'local' : 'remote');
    renderMarket();
    return;
  } catch (err) {
    MARKET = null;
    MARKET_BASE_URL = null;
    $('marketStatus').textContent = '市场不可用';
    setMarketSource('来源：不可用', 'error');
    $('marketGrid').innerHTML = `<div class="market-empty">市场加载失败：${escapeMarketHtml(err.message || err)}<br>已尝试远程 GitHub 源和本地示例；请检查网络，或在 app.js 的 MARKET_INDEX_URLS 中配置可用地址。</div>`;
  } finally {
    marketLoading = false;
  }
}

function validateMarketFrames(frames) {
  if (!Array.isArray(frames) || !frames.length) throw new Error('帧数据为空');
  if (frames.length > 600) throw new Error('帧数超过上限');
  for (const frame of frames) {
    if (!frame || typeof frame !== 'object' || Array.isArray(frame)) throw new Error('帧格式不对');
    for (const [key, rgb] of Object.entries(frame)) {
      if (!/^\d+$/.test(key) || !Array.isArray(rgb) || rgb.length !== 3
          || rgb.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) {
        throw new Error('帧颜色格式不对');
      }
    }
  }
  return frames;
}

async function installMarketAnimation(item) {
  const status = $('marketStatus');
  const url = marketAssetUrl(item.frames_url);
  if (!url) throw new Error('帧地址无效');
  status.textContent = `下载「${item.name}」…`;
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error('下载失败 HTTP ' + res.status);
  const buf = await res.arrayBuffer();
  if (item.sha256 && window.crypto && crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', buf);
    const hex = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
    if (hex !== item.sha256) throw new Error('SHA-256 校验失败，已拒绝安装');
  }
  const payload = JSON.parse(new TextDecoder().decode(buf));
  const frames = validateMarketFrames(Array.isArray(payload) ? payload : payload.frames);
  const layout = (META && META.model_name) || S.layoutModel || '';
  const out = await api('/api/studio/save', {
    name: item.name || item.id,
    fps: Math.max(1, Math.min(24, Number(item.fps) || 8)),
    smooth: !!item.smooth,
    frames,
    layout,
  });
  if (!out || !out.ok) throw new Error((out && out.error) || '保存失败');
  if (out.effects) renderEffects(out.effects);
  await loadProjects(out.project && out.project.file);
  await refreshMarketInstalled();
  renderMarket();
  status.textContent = `已安装「${item.name}」`;
}

async function uninstallMarketAnimation(item) {
  const res = await api('/api/studio');
  const project = (res.projects || []).find((p) => p.name === item.name);
  if (!project) throw new Error('本地找不到这个项目，可能已手动删除');
  const out = await api('/api/studio/delete', { file: project.file });
  if (out && out.effects) renderEffects(out.effects);
  await loadProjects();
  await refreshMarketInstalled();
  renderMarket();
  $('marketStatus').textContent = `已卸载「${item.name}」`;
}

function initMarket() {
  if (!$('marketGrid')) return;
  $('marketSearch').addEventListener('input', renderMarket);
  $('marketRefresh').addEventListener('click', () => loadMarket(true));
  $('marketGrid').addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-market-action]');
    if (!btn || !MARKET) return;
    const item = (MARKET.animations || []).find((a) => a.id === btn.dataset.marketId);
    if (!item) return;
    btn.disabled = true;
    try {
      if (btn.dataset.marketAction === 'install') await installMarketAnimation(item);
      else await uninstallMarketAnimation(item);
    } catch (err) {
      const raw = String((err && err.message) || err);
      $('marketStatus').textContent = /PermissionError|Permission denied|Errno 13|拒绝访问/i.test(raw)
        ? '操作失败：程序没有写入权限，请从桌面双击启动 AULA_LED.exe 后重试。'
        : '操作失败：' + raw;
    } finally {
      btn.disabled = false;
    }
  });
}

// ---------- 请我喝奶茶（自愿赞赏，微信/支付宝双码） ----------
function initDonate() {
  const mask = $('donateMask');
  const img = $('donateImg');
  const missing = $('donateMissing');
  if (!mask) return;
  const warn = $('donateTampered');
  const tabsBox = $('donateTabs');
  const store = {};          // {wechat: {mime,data}, alipay: {...}}
  let active = 'wechat';
  const render = () => {
    if (store[active]) {
      img.src = 'data:' + store[active].mime + ';base64,' + store[active].data;
      img.hidden = false;
    } else {
      img.hidden = true;
    }
  };
  const markTabs = () => {
    const avail = ['wechat', 'alipay'].filter((k) => store[k]);
    if (!store[active]) active = avail[0] || active;
    tabsBox.hidden = avail.length < 2;   // 只有一码时不显示切换
    tabsBox.querySelectorAll('.donate-tab').forEach((b) => {
      b.classList.toggle('active', b.dataset.ch === active);
    });
  };
  const loadQr = () => {
    img.hidden = true;
    missing.hidden = true;
    if (warn) warn.hidden = true;
    // 先清掉上一次的缓存和标签：否则被篡改/缺图/请求失败时，
    // 旧二维码仍留在内存里，点旧标签还能显示出来，和红色警告矛盾。
    Object.keys(store).forEach((k) => delete store[k]);
    tabsBox.hidden = true;
    // 收款码由后端校验 SHA-256 指纹后下发（指纹编译进 exe），被篡改会拒绝
    fetch('/api/donate', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => {
        if (d && d.ok && d.channels) {
          Object.assign(store, d.channels);
          markTabs();
          render();
        } else if (d && d.tampered) {
          if (warn) warn.hidden = false;
        } else {
          missing.hidden = false;
        }
      })
      .catch(() => { missing.hidden = false; });
  };
  tabsBox.addEventListener('click', (ev) => {
    const b = ev.target.closest('.donate-tab');
    if (!b || b.dataset.ch === active || !store[b.dataset.ch]) return;
    active = b.dataset.ch;
    markTabs();
    render();
  });
  $('donateBtn').addEventListener('click', () => {
    mask.hidden = false;
    loadQr();
  });
  $('donateClose').addEventListener('click', () => { mask.hidden = true; });
  mask.addEventListener('click', (ev) => {
    if (ev.target === mask) mask.hidden = true;
  });
  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape' && !mask.hidden) mask.hidden = true;
  });
}

// ==================== 版本与更新 ====================
const UPDATE_CONFIG_URL = 'update.json';
let UPDATE_INFO = null;

function parseVer(text) {
  return String(text || '').replace(/^v/i, '').split(/[.\-+_]/).map((x) => parseInt(x, 10) || 0);
}

function verGt(a, b) {
  const x = parseVer(a);
  const y = parseVer(b);
  for (let i = 0; i < Math.max(x.length, y.length); i += 1) {
    const v = x[i] || 0;
    const w = y[i] || 0;
    if (v !== w) return v > w;
  }
  return false;
}

async function loadUpdateManifest() {
  const cfgRes = await fetch(UPDATE_CONFIG_URL + '?t=' + Date.now(), { cache: 'no-store' });
  if (!cfgRes.ok) throw new Error('读取更新配置失败（HTTP ' + cfgRes.status + '）');
  const cfg = await cfgRes.json();
  const url = cfg.manifest;
  if (!url) throw new Error('更新配置里没有 manifest 地址');
  const res = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) throw new Error('读取版本清单失败（HTTP ' + res.status + '）');
  return res.json();
}

async function checkUpdate(silent) {
  const status = $('updateStatus');
  const notes = $('updateNotes');
  const dl = $('updateDownload');
  if (!status || !notes || !dl) return;
  const current = (META && META.version) || '';
  if (!silent) {
    status.hidden = false;
    status.style.color = '';
    status.textContent = '正在检查更新…';
  }
  try {
    const info = await loadUpdateManifest();
    UPDATE_INFO = info;
    const latest = info.version || '';
    if (verGt(latest, current)) {
      status.hidden = false;
      status.style.color = 'var(--accent)';
      status.textContent = '发现新版本 ' + latest + '（当前 ' + current + '）。点「下载更新包」，下载完成后双击程序目录里的 更新.bat。';
      notes.hidden = !info.notes;
      notes.textContent = info.notes || '';
      dl.hidden = false;
    } else {
      status.hidden = false;
      status.style.color = '';
      status.textContent = '已是最新版本（' + current + '）。';
      notes.hidden = true;
      dl.hidden = true;
    }
  } catch (err) {
    if (!silent) {
      status.hidden = false;
      status.style.color = 'var(--warn, #f0883e)';
      status.textContent = '检查更新失败：' + (err.message || err);
    }
  }
}

function initUpdate() {
  const btn = $('updateCheck');
  if (!btn) return;
  if (META && META.version) $('updateCurrent').textContent = META.version;
  btn.addEventListener('click', () => checkUpdate(false));
  $('updateDownload').addEventListener('click', () => {
    if (UPDATE_INFO && UPDATE_INFO.url) window.open(UPDATE_INFO.url, '_blank', 'noopener');
  });
  if (location.hash === '#update') {
    const fold = document.querySelector('details.fold');
    if (fold) fold.open = true;
    setTimeout(() => {
      const el = $('updateCheck');
      if (el) el.scrollIntoView({ block: 'center' });
    }, 700);
  }
  setTimeout(() => checkUpdate(true), 1500);
}

// 所有函数与常量就绪后再启动
boot();
initDonate();
initMarket();
initMarketUpload();
initOpenBrowser();
initAppRefresh();
initUpdate();
