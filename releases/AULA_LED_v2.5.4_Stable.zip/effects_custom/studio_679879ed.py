# -*- coding: utf-8 -*-
"""爱心渐出渐入

由可视化编辑器生成（2026-11-07 22:30）。想继续改：打开控制台的「动画编辑器」加载同名项目。
想手改：直接改下面的 render()，改完在界面点「重新加载插件」。
"""

import base64
import zlib

ID = 'studio_679879ed'
LABEL = '爱心渐出渐入'
FPS = float(8.0)          # 每秒播放几帧（编辑器里的「帧率」）
SMOOTH = True    # 相邻帧之间是否做渐变过渡

_DATA = (
    'eNrtmEGuwyAMRK/CAVgEGwMp97/Xh1Xwl0Cu5SSqxNICxvNGKXEa4QNEHosPR6hxrFxE4ZqjpNrp'
    '0qk7R3mhws5F0qkgWKiEsXJLTaUKolBTrRK1KowolrkKLFSQhJouMs3EnmveAVDaD5OuOx1TLy6x'
    'fjmIfS6cYbbwSUHqOsW7GbBYMBDoiBLp+IAsaPG0Zyd8MwlIN+Ry7FyeyoXiTumVlFxgr8pae51O'
    'HxJ6CLm2lgFPf4KHmGoL6qo64rhG4xrf2aKZneuIUpUi1oRphx6GtF9Wdg9iL3HhjO1c+rRxrWWQ'
    'EvUHb+Rjml/Qkj17PE2SgGdzMUqifI72cz98uwV+Jggteptcr8uto4+Vkv0BWhx9ytltaOV8nIi9'
    'SBznkxNpGVauVz7bF+dYLXzKnTEvX/Rr38ljNe9no6lWIbHK4lz/T2JQWZ5LUpWIJircC96tojzX'
    'dw5XOV4FW6n7u2oyC+fMJ+N/ZVnNzTvUHeqPhFrvmb1tpm3tWDkfrXpYw5XZw2Jl4SW7e3dQO6gd'
    '1CtB/QHuS4Lo'
)


def _decode():
    text = zlib.decompress(base64.b64decode(_DATA)).decode('ascii')
    frames = []
    for chunk in text.split(';'):
        frame = {}
        for item in chunk.split(' '):
            if not item:
                continue
            key, rgb = item.split(':')
            r, g, b = rgb.split(',')
            frame[int(key)] = (int(r), int(g), int(b))
        frames.append(frame)
    return frames


_FRAMES = _decode()


def render(t, ctx):
    frames = _FRAMES
    if not frames:
        return {k: (0, 0, 0) for k in ctx.keys}
    if len(frames) == 1:
        only = frames[0]
        return {k: only.get(k, (0, 0, 0)) for k in ctx.keys}

    pos = t * FPS
    index = int(pos) % len(frames)
    if not SMOOTH:
        current = frames[index]
        return {k: current.get(k, (0, 0, 0)) for k in ctx.keys}

    frac = pos - int(pos)
    a = frames[index]
    b = frames[(index + 1) % len(frames)]
    out = {}
    for key in ctx.keys:
        ca = a.get(key)
        cb = b.get(key)
        if ca is None and cb is None:
            out[key] = (0, 0, 0)
            continue
        ca = ca or (0, 0, 0)
        cb = cb or (0, 0, 0)
        out[key] = (int(ca[0] + (cb[0] - ca[0]) * frac),
                    int(ca[1] + (cb[1] - ca[1]) * frac),
                    int(ca[2] + (cb[2] - ca[2]) * frac))
    return out
