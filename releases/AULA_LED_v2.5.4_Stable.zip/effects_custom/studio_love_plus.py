# -*- coding: utf-8 -*-
"""love plus

由可视化编辑器生成（2026-11-07 22:30）。想继续改：打开控制台的「动画编辑器」加载同名项目。
想手改：直接改下面的 render()，改完在界面点「重新加载插件」。
"""

import base64
import zlib

ID = 'studio_love_plus'
LABEL = 'love plus'
FPS = float(7.0)          # 每秒播放几帧（编辑器里的「帧率」）
SMOOTH = True    # 相邻帧之间是否做渐变过渡

_DATA = (
    'eNrtnWuyqyoQhaeSAeSHImi8Z/7zuhoSWI2a6BYUzKo6p4pVhld3fyoNyVbdf8qY++v/P9WivKng'
    'qpFXP39Yy6ub6jby6p6mlLwaseVaXk3XUSWvHtVv3curZw3jIa7mMqpOjirPQcqrZYxZfrjIKci6'
    'nFF+M7qpx09N8KbVL8/3Zgyn72Xb0RpL1ri1DxpnpXFubU9b/c1Wt66i6aKY7tbVtGQKS97qStOy'
    'SSzbNTT0MYZWtPt6u7d0wylu0PRKDl6p6aT8nVTRZ6X5rOnpwtJdSI9ezaMdHXxtB7f090/529D9'
    'v+x+zWhgNDgXNgwOBsdScCjGCmNlZazUDB2Gzt9Cp2IkMZJiRJLqGVgMLAbWisDSDeOMcZZZnJmW'
    'YcewOzvsTMcoZBRmFoXmwaBkUOYdlKZnjDJGy4rRiiHLkC06ZGtGMCP4ShGsGNAM6AsHdMP4Znz/'
    'TnxrhjvD/WfDnRtpjP4k0U8YCANheIWsIhtkg2zMslETFaJCVNagUpEckkNytpOje4JEkAjSfpAe'
    '5IpckavoXHXEjJgRs9SYtaSO1JG6g6kzhJAQEsJzIdRk8oJM6rvphn8kkkSSyPyIdKJUHt8TII2k'
    '8Vo0OlEmi29RLInvCZDDH1w7kkSSSBIjkfj23/4cjiDRiWJWi4JEJ8rk0IliKHyPOGMG30NMSqDj'
    'ZncOVRDoRDHZGkGgE8WsDQWBTpzJnyMMRzRlz4kzyXOoTbhzAqM6KnMvtX/XQjDnXvqKyY8K5pw4'
    'lDjHDY5nRSZG8OZEJrQF75uCNycyoS14ygneHEKbV3uJeAveMgVxTkTmzbWL3tu9FyFocyIya46L'
    'CWl7sp6CNicis+YwmZC2aW0naHMiMmuOmQlpm9Z0n2hz11ZkVlLRFrxTCt6c2Eybq5mOteBtUtDm'
    'xGbWXM10pAXvkYI1JzaT5jCIyFnwFilIc0Rs5szVjEhZ8A7pwMqUsuA9UnDmxB7KDttfF6Q5sYez'
    'w3byBGtO7CEtXb5S0OYEjqbF0XzhjCfNxHukIM4JtNqUtkzOswjinMDontKWyc65IM5hhPE9pY37'
    'Axc/5blMXxHnyZYJ5OkVssgT1zzfSSbJ5ClM1qq5ty2RJJJRkYSwIpFfiEQErwAkzGDgEZUSqkwa'
    'YQZlwogqKYvQUbYoIm0hicHrKl7sUeUDItK1hUNU2WCIoIlgmkCIqpB3VAkhqLTPQ0RS2O1IBBGk'
    'kMBNK0bJIKoDEcRuQwI3vZpKCFEdyCCiFCL4+bVUQojqQAYRKzGkr6vEwxAMnoOSQVRREUTKQgIj'
    'Jm0kg6iiIogNhwRGXB1KBlFFRRBZCQncszKUDKKKiiBSFhKYLlGDvIrwHgn0cvOaUBKIaiOAyFjI'
    '32FZU0kgqo0AYtWQv8PSM5JAVBsBRBZC/tKlZiSBCMpGALFqyF/ETCkiJqz0/RG4A8DgNVQSiBhN'
    'AMSLIX+ZbFtIAlFNAMSLIX+Z5EclgagmAGLsh/ydlRuVBKKaAIgXQ/7SbVXsADBdWlQiiCoksIid'
    'Q8kgqhDBIvYoJISoQgbz3KCQFKIKITxsw1BSeNruBB+EfBDyQXjog5BrQa4FuRY8ci3IbCizocyG'
    '7t2Q2JIN5Y4gdwS5I7hzT/7jZsTHUzESPx6KOfhQTMAfT8WkPhUjAYx2ME0CeIFzaRuOiEoEeUL0'
    '+BOinyjkAdEvyRjd3St+eSKTL09IFPndiUt8nelJ2F9otKLgLxc+J8DvMZHFjSw+4yY1iZaudVsU'
    'gkQriuXwKUqm8DmBvBl8DtHgPT1v/ixwiekL3kslf6NauUEo+LOipK/YC/6sOJk+CxSO6E2eFXPc'
    'WXEydZasOeaCp569djJzlqs54iK+e9pH3LqV4AbmgrdPQZ0VyZmzDzG8BygczboFoODNiuS02W7m'
    'WNv0timIsyI5b5abOdo+v2UK3qxITpslao61zys9+1H0VXzSIp4EFbTZyI/Amm1ojrSIx88Eb1ZE'
    'oM02NMdaxLWd4M2KCLRZMuZY27OmE7xZEYE2S8Yca3vyKoI3S1TeP0ghiLNiFW/2o3O0HXboWhBn'
    'xSre7EfnaDsslyKIs2IVbzb652hLl0MRxFmxijeLwhxt6fKYgjgr8v4BGEGcFWixWdoy+Xk0QZwV'
    'GN2ztGWSuxTEWYHxPUvbWTlLQZzFCGNnlraz9g1KIC54q1xmrogfJVzmrohdg2X28twxWOaPP0TI'
    'px6fenzqZbyuy3rllvXaLKvVF9dX3/KHJ+cAz83jHZ2LOzyfdnC6ero19H0DZ1NAzWzh7Ntoqe6q'
    '0R+2WeJvhsTfski8/Tfdct+8ETez7f11+/nTwY9lb3zdCN68IfvJquuPMUwPEc3abXpYZ9vWvA3n'
    '7ydRMCxtne+nQYQhPpymEmaYnmkUU52bkEDyNSG9OOx2eu+zVxZHKsf2oVPs53Ubf3W61M+/5dZe'
    'z50tTf9rRGtRm65xCqf00zSFdKq7rEbwWodmORzdlzK2qsiB1uWPWl1sCs2V56PTTe5q8+EU/jaF'
    'uJScPoXu3UBVKObt+2NupVr5VVPl10yVX3jGmewZzESZLHbV+M83rS92vvjwxd4VCzaLXAt5Gynf'
    'hvJtKF9RgX1imLDK1ZryFne0aVNa01zOtH9ZCef8gF87hdNHvSmmVezb7/Zo95Uzj+iirdx9MXmV'
    'u8FTpn5OWSPEfRj89C1kzwOz8u6vvBkr3liOflmR1o9ucFp5erOoeHc4PEsZx3rMaDIdyIwmM5rM'
    'aF4/o1kxucnkJpObTG4yucnkJnMQTG4yucnkJpObTG4ywpncZHKTyU0mN5ncZHKTyU0mN5ncZHKT'
    'yU0mN5ncZHKTyU0mN5ncZHLz924szGcmMiyzlhlY6Ph05Nm5ldUPpmPG9iELcNQITun0sH4SNh21'
    'tf0N/KXOyo8tX0Hx/EPKj8eo9PMHlbwY/4ivE69fe9LtvTbd+3ecrIrQxPtHyN6qX2y+7pb6aqql'
    'jrVeHIXpYo+pfiQcoHkkHe5wX1sz9uHms2YiuvvTrEx/4Bzr7RMeXhI2z173MUyhzjKM3mmlpttr'
    'suo69uuiGrOKatkmvplx6Ktt7n4B8MddoHPxRycaef0EIn11BV/p5l7f60fz9JUXDxQ9iNFXXmAD'
    'ChtQ2MDoKy8aFAYFNqCxzugrL7BTLergQA02YLBTgw0YHMHoqkrfdXWv1ePpKlA9qtFVoLCRVjTS'
    'ikZa0UgnGhld5dXTVU4+XVWp+9BHY7Hy4oGiBzG6ygtsQGEDChsYXeVFg8KgwAY01hld5QV2qkUd'
    'HKjBBgx2arABgyMYXFW39b0ZVFWPrkLVoxpchQobaUUjrWikFY10opHBVaBGV3k5uqobIuHe16Oj'
    'XPHhi70rDi5yRV9N+WrKVxtc44qNLxpf9NW0/+zgEFf0XWj4rB+O8dWM78L4asb3NjqgftyVuXf6'
    'aX8vehCj9b3w1Vus3mL1Fqt3WH00uxNPq7/VaPSmHe6Vuh2N7ooPX+xdcTC6K/pqyldTvtpgdFds'
    'fNH4oq+m/WcHo7ui70LDZ/1wjK9mfBfGVzO+t8HonRru3Xf9/KMdvtz78mBxX/ZVW6jaQtUWqnZQ'
    'dTC2K4+2fot///4HfZUZ6Q=='
)


def _decode():
    text = zlib.decompress(base64.b64decode(_DATA)).decode('ascii')
    frames = []
    for chunk in text.split(';'):
        frame = {}
        for item in chunk.split(' '):
            if not item:
                continue
            key, rgb = item.split(':')
            r, g, b = rgb.split(',')
            frame[int(key)] = (int(r), int(g), int(b))
        frames.append(frame)
    return frames


_FRAMES = _decode()


def render(t, ctx):
    frames = _FRAMES
    if not frames:
        return {k: (0, 0, 0) for k in ctx.keys}
    if len(frames) == 1:
        only = frames[0]
        return {k: only.get(k, (0, 0, 0)) for k in ctx.keys}

    pos = t * FPS
    index = int(pos) % len(frames)
    if not SMOOTH:
        current = frames[index]
        return {k: current.get(k, (0, 0, 0)) for k in ctx.keys}

    frac = pos - int(pos)
    a = frames[index]
    b = frames[(index + 1) % len(frames)]
    out = {}
    for key in ctx.keys:
        ca = a.get(key)
        cb = b.get(key)
        if ca is None and cb is None:
            out[key] = (0, 0, 0)
            continue
        ca = ca or (0, 0, 0)
        cb = cb or (0, 0, 0)
        out[key] = (int(ca[0] + (cb[0] - ca[0]) * frac),
                    int(ca[1] + (cb[1] - ca[1]) * frac),
                    int(ca[2] + (cb[2] - ca[2]) * frac))
    return out
