# -*- coding: utf-8 -*-
"""示例 4：雷达扫描 —— 演示「极坐标 + 拖尾」的写法。

一条光束绕键盘中心匀速旋转，扫过的键留下逐渐熄灭的余晖。
坐标被换算成以键盘中心为原点的极坐标（半径 + 角度），这类效果全靠它。

技巧点：
  · 角度差要处理「跨 0 度」的情况（用 (a - b + pi) % tau - pi 取最短角差）；
  · 拖尾 = 只让「在光束后方一小段角度内」的键发光，越靠后越暗；
  · 中心点附近不要算角度（半径太小），否则中间几颗键会疯狂闪烁。
"""

import colorsys
import math

ID = 'custom_radar'
LABEL = '雷达扫描'
REACTIVE = False

CENTER_X = 9.0
CENTER_Y = 2.0
SPAN = 1.15          # 光束张开的角度（弧度）


def render(t, ctx):
    base = ctx.params.get('color', (90, 255, 170))
    hue0 = _hue_of(base)

    out = {}
    sweep = (t * 1.7) % math.tau          # 光束当前角度
    for key in ctx.keys:
        x, y = ctx.coords[key]
        dx = (x - CENTER_X) / 9.0         # 归一化，避免键盘很宽时半径过大
        dy = (y - CENTER_Y) * 1.4
        radius = math.hypot(dx, dy)
        if radius < 0.001:
            angle = 0.0
        else:
            angle = math.atan2(dy, dx)

        # 光束后方的最短角差：0 = 刚好被扫到，越大 = 越久之前被扫到
        behind = (sweep - angle + math.pi) % math.tau - math.pi
        if 0.0 <= behind < SPAN:
            level = (1.0 - behind / SPAN) ** 2.0
        else:
            level = 0.0

        # 圆心亮、边缘暗，像真的雷达屏
        falloff = 0.35 + 0.65 * max(0.0, 1.0 - radius)
        v = level * falloff
        hue = (hue0 + radius * 0.12) % 1.0
        r, g, b = colorsys.hsv_to_rgb(hue, 0.8, 1.0)
        # 静止底色：很淡的一圈，让键盘不至于全黑
        floor = (0.03 + 0.05 * falloff) * ctx.params.get('dark', 1.0)
        total = min(1.0, v + floor)          # 一定要 clamp，超过 255 会被截断成怪颜色
        out[key] = (min(255, int(r * 255 * total)),
                    min(255, int(g * 255 * total)),
                    min(255, int(b * 255 * total)))
    return out


def _hue_of(rgb):
    r, g, b = (c / 255.0 for c in rgb)
    return colorsys.rgb_to_hsv(r, g, b)[0]
