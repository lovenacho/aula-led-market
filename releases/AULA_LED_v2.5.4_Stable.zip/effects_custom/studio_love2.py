# -*- coding: utf-8 -*-
"""love2

由可视化编辑器生成（2026-11-07 22:30）。想继续改：打开控制台的「动画编辑器」加载同名项目。
想手改：直接改下面的 render()，改完在界面点「重新加载插件」。
"""

import base64
import zlib

ID = 'studio_love2'
LABEL = 'love2'
FPS = float(9.0)          # 每秒播放几帧（编辑器里的「帧率」）
SMOOTH = True    # 相邻帧之间是否做渐变过渡

_DATA = (
    'eNrtlVuShCAMRbfCAvwQkvAY9r+vmbLoRqzGB+o0YD6sCiVJ7j1BkfijiAbQgwLj5XwllN35TqAq'
    '2imILsgT2lxeRWh7c02hXb6DNPX0g7HW7ohtaCHThjKyLeokV49qNG14AGjRkXSd+7PsNriV7P2o'
    'dyAmcY4EOuZyIxf1KErjc5mBYYJhhczzRp6G6TZGd2TWTbMGJl8FeeQ5dDsH4ql0MxUhR+Qh1T4k'
    'Azyy1kamdg/QezMfhV8ISFI15sWlVVaxJaMnlUd6jZbFsdD5QwLpUXMrB6gifyqpopIqKslTeuVz'
    'YS69cumPRE2OSrV4H26h8CyWAmH/W0G6ePPr6ijKDRdbUSmk8sqwqHxbI5ksRSV9AZqXgeYyVeED'
    'HIfx9fVNIcVQv8N1BxBzYJZjYmhj6N5h+B9M4QkGaNNlbECxQfhHTmH0TdH3BsmYo2NOuDymMCJI'
    'qb9u1783PIDVAeCRk939PHgAXx4AE38AcUZcMWJmmmHaIcQ+qT0IE3O5gAuDuAzEc503Y7XM3xlT'
    'R5xsyj+i+ajQT+p8Rsdm810dN9t8rp0r6Gep8/3pJj8DXnjiCo97YbevfZ49/3rYWzuG/lfkkW7+'
    'FxDuwAQ='
)


def _decode():
    text = zlib.decompress(base64.b64decode(_DATA)).decode('ascii')
    frames = []
    for chunk in text.split(';'):
        frame = {}
        for item in chunk.split(' '):
            if not item:
                continue
            key, rgb = item.split(':')
            r, g, b = rgb.split(',')
            frame[int(key)] = (int(r), int(g), int(b))
        frames.append(frame)
    return frames


_FRAMES = _decode()


def render(t, ctx):
    frames = _FRAMES
    if not frames:
        return {k: (0, 0, 0) for k in ctx.keys}
    if len(frames) == 1:
        only = frames[0]
        return {k: only.get(k, (0, 0, 0)) for k in ctx.keys}

    pos = t * FPS
    index = int(pos) % len(frames)
    if not SMOOTH:
        current = frames[index]
        return {k: current.get(k, (0, 0, 0)) for k in ctx.keys}

    frac = pos - int(pos)
    a = frames[index]
    b = frames[(index + 1) % len(frames)]
    out = {}
    for key in ctx.keys:
        ca = a.get(key)
        cb = b.get(key)
        if ca is None and cb is None:
            out[key] = (0, 0, 0)
            continue
        ca = ca or (0, 0, 0)
        cb = cb or (0, 0, 0)
        out[key] = (int(ca[0] + (cb[0] - ca[0]) * frac),
                    int(ca[1] + (cb[1] - ca[1]) * frac),
                    int(ca[2] + (cb[2] - ca[2]) * frac))
    return out
