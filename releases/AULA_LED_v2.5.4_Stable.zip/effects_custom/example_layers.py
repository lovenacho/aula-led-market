# -*- coding: utf-8 -*-
"""示例 5：分层叠加 —— 演示怎么把几种效果「叠」在一起。

三层：
  第 1 层  慢速呼吸的斜向渐变（当作底色，亮度压得很低）
  第 2 层  按键白闪：按下的键立刻变白，然后 0.45 秒内衰减回第 1 层
  第 3 层  每 4 秒一次的整块键盘「心跳」，所有键一起微微亮一下

绝大多数好看的动画都是这么叠出来的：先想清楚有哪几层，再分别算、最后相加。
相加时记得 clamp 到 0~255，超了会被协议层截断（颜色会变得很怪）。
"""

import math

ID = 'custom_layers'
LABEL = '分层叠加'
REACTIVE = True

_flash = {}          # 键号 -> 按下时间


def render(t, ctx):
    base = ctx.params.get('color', (120, 140, 255))
    now = ctx.now

    for key, stamp in ctx.events:
        _flash[key] = stamp
    for key in ctx.pressed:
        _flash[key] = now

    # 第 3 层：心跳，周期 4 秒
    beat = max(0.0, math.sin(t * math.pi / 2.0)) ** 6 * 0.25

    out = {}
    for key in ctx.keys:
        x, y = ctx.coords[key]

        # 第 1 层：斜向渐变 + 呼吸
        wave = 0.5 + 0.5 * math.sin((x * 0.45 + y * 0.9) - t * 1.2)
        level = 0.06 * ctx.params.get('dark', 1.0) + 0.16 * wave + beat

        r = base[0] * level
        g = base[1] * level
        b = base[2] * level

        # 第 2 层：按键白闪，指数衰减
        stamp = _flash.get(key)
        if stamp is not None:
            age = now - stamp
            if age < 0.45:
                k = math.exp(-age * 7.0)
                r += 255 * k
                g += 255 * k
                b += 255 * k
            else:
                _flash.pop(key, None)

        out[key] = (min(255, int(r)), min(255, int(g)), min(255, int(b)))
    return out
