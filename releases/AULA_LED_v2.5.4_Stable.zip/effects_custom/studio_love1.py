# -*- coding: utf-8 -*-
"""love1

由可视化编辑器生成（2026-11-07 22:30）。想继续改：打开控制台的「动画编辑器」加载同名项目。
想手改：直接改下面的 render()，改完在界面点「重新加载插件」。
"""

import base64
import zlib

ID = 'studio_love1'
LABEL = 'love1'
FPS = float(5.0)          # 每秒播放几帧（编辑器里的「帧率」）
SMOOTH = True    # 相邻帧之间是否做渐变过渡

_DATA = (
    'eNrtmVGqpDAQRbfyFuBHG6vKZGb/+xojYu55fkhGQYSGFuoS63qteKAho/1J6TOMcwxpzD+jUwbl'
    'TJkpC2T6UI6UfG6ic6JzovNEqylRTpR8kLHX2Gt8X2MqYyqns3N0Tiunlf+y4gsGRxfMHHQOOged'
    'g84znWe+/szRjR+84d/xqW9lSTkN6+8nTVL/+oZclkLqrm/r0xqvfGeThJkkzDRLnaUurTbJcPK9'
    'yjTMpJand33TJjFcYvgotWyHS4DHeJA8IXlCBhIykDv5kbG8hqWwYf1Vllp9YKkthdSdLO2NF1lq'
    'PhJmYanVWerSapMMpyy1O01qeXovS3ujS4yFpVbLdrgEeJClPUNInpCBhAzkXpZ229ewVGxYf5Wl'
    'Vh9YakshdSdLe+NFlpqPhFlYanWWurTaJMMpS+1Ok1qe3svS3ugSY2Gp1bIdLgEeZGnPEJInZCAh'
    'A7mXpd32NSyNKQ/bVXGCPBCF1aDs5Ep7L6IFK6ZaAIPMlAXSmOoUNtxslEzVS532OlMt7EFyB52p'
    'HoRQYwRTBWcVnNW9QKrze5iMGLZrZVLlkUldDcpeJqX3KpNqxVSVSZWZskAaU50zqTcbJVN1Mym9'
    'zlSVSZXcQWeqJ5mUGMFUwVkFZ3Uzk+L8ZfLL5JfJL5P/x+TyX3u7ViZVHpnU1aDsZVJ6rzKpVkxV'
    'mVSZKQukMdU5k3qzUTJVN5PS60xVmVTJHXSmepJJiRFMFZxVcFY3MynO7zkzSDZs13psoPJ4cqCr'
    'Qdl7fiC9V48Q1Iqp6kGCykxZII2pzg8V9GajZKru0wXpdaaqZwwquYPOVE8eNkiMYKrgrIKzuvng'
    'QZzfw6T7sF0rkyqPTOpqUPYyKb1XmVQrpqpMqsyUBdKY6pxJvdkomaqbSel1pqpMquQOOlM9yaTE'
    'CKYKzio4q5uZFOcuJv8BcmqDiA=='
)


def _decode():
    text = zlib.decompress(base64.b64decode(_DATA)).decode('ascii')
    frames = []
    for chunk in text.split(';'):
        frame = {}
        for item in chunk.split(' '):
            if not item:
                continue
            key, rgb = item.split(':')
            r, g, b = rgb.split(',')
            frame[int(key)] = (int(r), int(g), int(b))
        frames.append(frame)
    return frames


_FRAMES = _decode()


def render(t, ctx):
    frames = _FRAMES
    if not frames:
        return {k: (0, 0, 0) for k in ctx.keys}
    if len(frames) == 1:
        only = frames[0]
        return {k: only.get(k, (0, 0, 0)) for k in ctx.keys}

    pos = t * FPS
    index = int(pos) % len(frames)
    if not SMOOTH:
        current = frames[index]
        return {k: current.get(k, (0, 0, 0)) for k in ctx.keys}

    frac = pos - int(pos)
    a = frames[index]
    b = frames[(index + 1) % len(frames)]
    out = {}
    for key in ctx.keys:
        ca = a.get(key)
        cb = b.get(key)
        if ca is None and cb is None:
            out[key] = (0, 0, 0)
            continue
        ca = ca or (0, 0, 0)
        cb = cb or (0, 0, 0)
        out[key] = (int(ca[0] + (cb[0] - ca[0]) * frac),
                    int(ca[1] + (cb[1] - ca[1]) * frac),
                    int(ca[2] + (cb[2] - ca[2]) * frac))
    return out
