# -*- coding: utf-8 -*-
"""奶龙眨眼

由可视化编辑器生成（2026-11-07 22:30）。想继续改：打开控制台的「动画编辑器」加载同名项目。
想手改：直接改下面的 render()，改完在界面点「重新加载插件」。
"""

import base64
import zlib

ID = 'studio_d08a64ef'
LABEL = '奶龙眨眼'
FPS = float(10.0)          # 每秒播放几帧（编辑器里的「帧率」）
SMOOTH = True    # 相邻帧之间是否做渐变过渡

_DATA = (
    'eNrt20FuhDAMRuGrzAFYkNhOgN7/Xu2iSHmbSrSLVtVTN1gj4Mfly0QTaHn1qq23fRvxaoVqXJFb'
    '77m1OF5tojpQnet+fUfVUHVUsR6lJ6pCNbDfRHWgOtf9Yr/27ePvFe3e6Pg81n0D3Qh0I9CNmPfh'
    'jnsD5030INGDRA8SPcj8PFzWvYHzJq48ceWJ/0Lt6351X371ewPnLVx54coLCQr3QeE+KCQY6MFA'
    'DwZ6MJBl4D4YuA8G7oOBbgx0YyDLRJaJLBNZJu6Iib5M9GUiy0SWE1lOZGl7ZxksSbJNlgdLHhn0'
    '3trXuNeKJ+E5vo97rZClI4u4fxX3WiFBIcEPcK8VsgxkEbe4xS1ucf9L3CtJZAlkCWR5xHytkCWQ'
    'JZDlEfi1QpZElkSWR/TXClkKWQpZHAQcBBwEHAQcBBwEnOY7zRe3uMUtbnH/WdwurYnbpTVxi1vc'
    '4nZa7rTcabnTcnGLW9ziFrdLZi6ZOQg4CPgN7ze8uP3hTdz+8CZucYtb3OIWt7jFLW5xi1vc4ha3'
    'uMUtbnGLW9ziFre4xS1ucYtb3OIWt7jFLW5xi9vHT3381MdPffxU3OIWt7h9e8y3x3x7zEHAQcBB'
    'wEHAQcBpvtN8p/niFre4xe3SmktrLq25tCZucYtb3OIWt7jFLW5xi1vc4ha3uMUtbnGLW9ziFre4'
    'xS1ucYtb3OIWt7gf4X4H6QtpdA=='
)


def _decode():
    text = zlib.decompress(base64.b64decode(_DATA)).decode('ascii')
    frames = []
    for chunk in text.split(';'):
        frame = {}
        for item in chunk.split(' '):
            if not item:
                continue
            key, rgb = item.split(':')
            r, g, b = rgb.split(',')
            frame[int(key)] = (int(r), int(g), int(b))
        frames.append(frame)
    return frames


_FRAMES = _decode()


def render(t, ctx):
    frames = _FRAMES
    if not frames:
        return {k: (0, 0, 0) for k in ctx.keys}
    if len(frames) == 1:
        only = frames[0]
        return {k: only.get(k, (0, 0, 0)) for k in ctx.keys}

    pos = t * FPS
    index = int(pos) % len(frames)
    if not SMOOTH:
        current = frames[index]
        return {k: current.get(k, (0, 0, 0)) for k in ctx.keys}

    frac = pos - int(pos)
    a = frames[index]
    b = frames[(index + 1) % len(frames)]
    out = {}
    for key in ctx.keys:
        ca = a.get(key)
        cb = b.get(key)
        if ca is None and cb is None:
            out[key] = (0, 0, 0)
            continue
        ca = ca or (0, 0, 0)
        cb = cb or (0, 0, 0)
        out[key] = (int(ca[0] + (cb[0] - ca[0]) * frac),
                    int(ca[1] + (cb[1] - ca[1]) * frac),
                    int(ca[2] + (cb[2] - ca[2]) * frac))
    return out
