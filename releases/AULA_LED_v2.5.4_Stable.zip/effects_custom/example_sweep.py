# -*- coding: utf-8 -*-
"""自定义动画示例 1：斜向扫描光带。

把这类文件放进 effects_custom/ 目录，点界面上的「重新加载插件」就能用。
可用的模块级变量：
    ID       效果唯一标识（英文）
    LABEL    界面上显示的名字
    REACTIVE 是否需要用按键事件（可选）

render(t, ctx) 必须返回 {键号: (r, g, b)}，键号就是 ctx.keys 里的那些。
ctx 常用成员：
    ctx.keys      所有键号
    ctx.coords    键号 -> (x 列, y 行)，可用来做空间动画
    ctx.t         运行时间（秒，已按速度缩放）
    ctx.dt        距上一帧的秒数（已按速度缩放）
    ctx.pressed   当前按下的键号集合
    ctx.events    本次新按下的事件 [(键号, 时间戳), ...]
    ctx.params    {'color': (r,g,b), 'brightness': 0~1, 'speed': ...}
"""

import math

ID = 'custom_sweep'
LABEL = '斜向扫描'
REACTIVE = False


def render(t, ctx):
    base = ctx.params.get('color', (0, 160, 255))
    # 底光跟随「背光强度」：背光拖到 0 时底色归零，彻底无光
    dk = ctx.params.get('dark', 1.0)
    out = {}
    for key in ctx.keys:
        x, y = ctx.coords[key]
        # 一条沿对角线滚动的亮带
        phase = (x * 0.5 + y * 1.3 - t * 3.0) % 8.0
        level = max(0.0, 1.0 - abs(phase - 4.0) / 2.2) ** 2
        # 底色 + 亮带，两个都要 clamp 到 0~255
        out[key] = (
            min(255, int(base[0] * level + 6 * dk)),
            min(255, int(base[1] * level + 8 * dk)),
            min(255, int(base[2] * level + 14 * dk)),
        )
    return out
