# -*- coding: utf-8 -*-
"""示例 3：按键爆裂粒子 —— 演示「用 dt 做物理」的写法。

按下一个键，就以它为中心炸开一圈粒子，粒子沿径向飞散、边飞边变暗并落回底光。
空间位置用 ctx.coords（键帽坐标），所以爆裂是真的按键盘平面扩散，不是按键号顺序。

技巧点：
  · 用 ctx.dt 累加位移（而不是用 t 直接算位置）—— 这样速度参数变动、掉帧都不会跳；
  · 粒子放在模块级列表里跨帧保存，但每帧要清理过期的，否则列表会无限增长；
  · 底光保持很暗（0.04），否则整块键盘太亮，看不出粒子在飞。
"""

import colorsys
import math
import random

ID = 'custom_particles'
LABEL = '按键爆裂'
REACTIVE = True

_particles = []          # [(x, y, vx, vy, 出生时间, 色相), ...]
_MAX = 260               # 同时存在的粒子上限，防止一秒钟猛敲把帧率拖垮


def _spawn(x, y, now, hue):
    for _ in range(9):                                    # 每次按键炸 9 颗
        angle = random.uniform(0, math.tau)
        speed = random.uniform(3.0, 9.0)                  # 单位：列/秒
        _particles.append((x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                           now, (hue + random.uniform(-0.08, 0.08)) % 1.0))


def render(t, ctx):
    base = ctx.params.get('color', (0, 200, 255))
    hue0 = _hue_of(base)
    now = ctx.now

    # 1) 新按下的键 -> 生成粒子
    for key, _stamp in ctx.events:
        pos = ctx.coords.get(key)
        if pos:
            _spawn(pos[0], pos[1], now, hue0)

    # 2) 按 dt 推进粒子（这里用 ctx.dt，已经按速度滑块缩放过了）
    life = 1.1
    dt = ctx.dt
    alive = []
    for x, y, vx, vy, born, hue in _particles:
        age = now - born
        if age > life:
            continue
        # 阻力：速度指数衰减，飞出去就慢慢停
        damp = math.exp(-dt * 2.2)
        alive.append((x + vx * dt, y + vy * dt, vx * damp, vy * damp, born, hue))
    _particles[:] = alive[-_MAX:]

    # 3) 粒子 -> 附近键的亮度（每个粒子只影响最近的 4 个键，够快也够好看）
    glow = {}
    for x, y, _vx, _vy, born, hue in _particles:
        level = max(0.0, 1.0 - (now - born) / life) ** 1.6
        if level < 0.02:
            continue
        near = sorted(ctx.keys, key=lambda k: _dist2(ctx.coords[k], x, y))[:4]
        for k in near:
            d2 = _dist2(ctx.coords[k], x, y)
            w = level * math.exp(-d2 * 0.55)
            if w <= 0.01:
                continue
            h, lv = glow.get(k, (hue, 0.0))
            glow[k] = (hue if w > lv else h, min(1.0, lv + w))

    # 4) 合成：底光 + 粒子
    out = {}
    for key in ctx.keys:
        h, lv = glow.get(key, (hue0, 0.0))
        if key in ctx.pressed:
            lv = min(1.0, lv + 0.55)
        r, g, b = colorsys.hsv_to_rgb(h, 0.85, 1.0)
        # 底光跟随「背光强度」：背光拖到 0 时这里归零，否则整块键盘会留一层微光
        lo = 0.04 * ctx.params.get('dark', 1.0)
        v = lo + (1 - lo) * lv
        out[key] = (int(r * 255 * v), int(g * 255 * v), int(b * 255 * v))
    return out


def _dist2(pos, x, y):
    dx = pos[0] - x
    dy = (pos[1] - y) * 1.6      # 行距比列距大，纵向乘个系数让扩散看起来是圆的
    return dx * dx + dy * dy


def _hue_of(rgb):
    r, g, b = (c / 255.0 for c in rgb)
    return colorsys.rgb_to_hsv(r, g, b)[0]
