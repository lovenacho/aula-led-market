# -*- coding: utf-8 -*-
"""love碰撞

由可视化编辑器生成（2026-11-07 22:30）。想继续改：打开控制台的「动画编辑器」加载同名项目。
想手改：直接改下面的 render()，改完在界面点「重新加载插件」。
"""

import base64
import zlib

ID = 'studio_love'
LABEL = 'love碰撞'
FPS = float(8.0)          # 每秒播放几帧（编辑器里的「帧率」）
SMOOTH = True    # 相邻帧之间是否做渐变过渡

_DATA = (
    'eNrtnF1y4yoQhbeSBeTBQgLJl/3v6zpPwyHDN20CEnZ4mJqiIBj6nKZ/RLNs/23Lp1se/7yPS9r6'
    'WLz0eekL0hekb5e+XfoO6Tuk7y59aevD3dLW7tKR2ueW4siPfZW/k5GuPPJjuYmYdKiToftCfyhD'
    'nUh7vxWniTrSCRLhXpwl6kgnKIWjOEvUkU4QDHtxlqgjNxGF98VZoo7cRLx+K84S3WH9uyB8dSKz'
    '4MsjV0ElCJqrrDoIt1ZZSxC+rsKCIEivumpBc5V1ekFsFcS8oLIKKl4kv4oEve5dpLTJ/jaRy7YB'
    'moLYFooYxU3Xqb+n6xR5brJOL/L0t7KUVC7ZLLfinIpmhjsdDarFiiatTDFSSdhX7V2RdbSjjPN0'
    'ZtJu9SRam0gi4+feXkp+LWpjrQSz0wZO/W/GA8xcLRB60OvB1AUkPTbCuQBmpuTeG1wxJQg1uhvk'
    'CfWggVpxtWSnU2SZhPkrYezeKjjZ55NpGZZafiCiHe9Au3LcdzUJby9CyW1Ygu7j0BXi3x+Qt5zQ'
    'GIrKGsi+DLHXF6F5GJb0R38VKOf7RlaI4w3Uw72ksvgXUZ39bEUqJ9WnWk21mmo11Wqq1VSrrmo1'
    'FWkq0q9TpCaqM5VlKstUlqksU1m6KMtICtFCBSbnu3J+KCZfy906tr4OPwfi4MWsO5tnVmaNzKVL'
    '2XM6X/oz5DU5cTIL+uPeBelXwbY7mj3wa4TYuBh1QKUNDrWSH0rWTaRbK0+7BC+WWaWU7HIhSVBB'
    'TJvd2vdHO6ICnNp10spkLU/8gjvMJWlb1cgPLGWz7t1+R8x+FdJ+V9d+KdxeN2Av7rCXuURzxBfN'
    '2YpozmRE7LOOpNwarsWeoYOkMcqFMoL2tDQVwGEJE2RqsPjIfhe5TVEmBfdY6QXpQq7VAU3CyBHy'
    'AJQN2s0aj/ELxJiQMcCzCP1tiHQoGs0yWnBmopdJXjvES9mvw9mOPhl5ruVIAK0O+jrk55W9YbSH'
    '6ImQN0WepNlbNPse6Af5UOe5Yumx9dNaVC/MPBLXac8F279qPPHR74mbJ0+c7lTHr68BmA1IrDSJ'
    '/zBDVHhi9weoDJXKSdEo2StkyK0gw261l+zUkFtRW5dNbkxlVTgl0bN3GMg3IXeADLLZQKIzQu4A'
    'JSLLa2H3g9wBMshkEsn9IAeATDAliMwhGzoAZJDJQNJayBkh56BH6oPSBj1SGMGcirAmH6oTGpTC'
    '2J3VqQBLVv3yCUoXglBkiIN3O4jl9Hekmwu8BUJnSNl2xMqPsxFGxis6V7BsJI1wM9uyG9iyFSwp'
    'YXgvW+7sdN/gdD/MXDusfkqWiPVwut9BQ1Y4z725iDrLLt3AmzRXNWIx7QoHLB23t6rnnLDGMVuL'
    'PZtcec/Jfp/uiR2BIadAJTMSsIce60TD0+L3IvxdBBMVwQxlBiQ77AMc6GX3Xw9eHalzxuzRq/KO'
    'dO953wZzBljLUXweK3sQK3ssyxXD46ioZH2uPGdtMGcOLGP1jdk2j0LVPvy0mL+n0BeGHneHp1zG'
    'lMuy3j/v7tNt4T3l8md/X3JJW5u0fNoaWi7JOh9ySVuLtGTvXvdeL5c2epTM+ZBL2tqldUhL9r7J'
    '3pvJpc35kszp5Bec7N3p3vvIZaRzt1Yu0x79Tjv9+O/z7j+X2/1LLmnLSyukrV8gl1o9SqWkMtul'
    'dUjrnrYecklb76FHPc7dREpeZPaQS9oSlnth+VueL23sdColldkmLeH8Lzh3a/26P1Ka9ug3xUcN'
    'zpd3399Ia2kzi7biE2Wf9ss13ldWpbgmDwrYF7rRF3T7a/72FxrGFYWjj/t0wWS3fqn51eLNPjDZ'
    'S1EWuO4OH24mgFcCmMan4vH/AECNcjV+qwVQozmNWnoAqPGN+uqnA5j8/CJB7z8ATFsMYAoSA6hB'
    'NgGYjmQANbS0A5j+ncjlegBTkFoBmLY091EPYNoSMf0AwLQls3hZyw8ATFsyS5BZgsyyyyy7rPML'
    'wCS4HArA/J5qezjzW1UT3L+Cm1/unVA/CzVfIn8DGrjMB64jhQOHiiiSJzXqCBPA9Zr0OZE+axMy'
    '8dsTDaiVXT61E41fEqmjXV5bfCUJ1yzwO5mSXM5/Ll25/qpI5W/VEhcS+1siOCVofhk07VshLuqv'
    'Aq5SIUJlrFWrHhsoS35F16o6/Nz+VKupVlOtplpNtWqvVlORpiJdrkjDKstQCnE26Yei+UjkvZSg'
    'Z5Pw7Yl2Opm6E6YHKboA3x/qLnA2gawWllrRg7CfkG6tBO1SIknQbmV/2Y5onf3X8j+yS8+c'
)


def _decode():
    text = zlib.decompress(base64.b64decode(_DATA)).decode('ascii')
    frames = []
    for chunk in text.split(';'):
        frame = {}
        for item in chunk.split(' '):
            if not item:
                continue
            key, rgb = item.split(':')
            r, g, b = rgb.split(',')
            frame[int(key)] = (int(r), int(g), int(b))
        frames.append(frame)
    return frames


_FRAMES = _decode()


def render(t, ctx):
    frames = _FRAMES
    if not frames:
        return {k: (0, 0, 0) for k in ctx.keys}
    if len(frames) == 1:
        only = frames[0]
        return {k: only.get(k, (0, 0, 0)) for k in ctx.keys}

    pos = t * FPS
    index = int(pos) % len(frames)
    if not SMOOTH:
        current = frames[index]
        return {k: current.get(k, (0, 0, 0)) for k in ctx.keys}

    frac = pos - int(pos)
    a = frames[index]
    b = frames[(index + 1) % len(frames)]
    out = {}
    for key in ctx.keys:
        ca = a.get(key)
        cb = b.get(key)
        if ca is None and cb is None:
            out[key] = (0, 0, 0)
            continue
        ca = ca or (0, 0, 0)
        cb = cb or (0, 0, 0)
        out[key] = (int(ca[0] + (cb[0] - ca[0]) * frac),
                    int(ca[1] + (cb[1] - ca[1]) * frac),
                    int(ca[2] + (cb[2] - ca[2]) * frac))
    return out
