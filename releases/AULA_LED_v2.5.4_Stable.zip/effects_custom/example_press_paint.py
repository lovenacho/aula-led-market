# -*- coding: utf-8 -*-
"""自定义动画示例 2：按键染色 + 自动褪色（演示 reactive 用法）。"""

import math

ID = 'custom_press_paint'
LABEL = '按键留色'
REACTIVE = True

_state = {}


def render(t, ctx):
    base = ctx.params.get('color', (255, 90, 120))
    for key, _stamp in ctx.events:
        _state[key] = (t, 1.0)

    out = {}
    for key in ctx.keys:
        stamp, _ = _state.get(key, (0.0, 0.0))
        age = t - stamp
        level = max(0.0, 1.0 - age / 2.5)
        if key in ctx.pressed:
            level = 1.0
        # 呼吸感的底光
        floor = (0.05 + 0.03 * math.sin(t * 1.5)) * ctx.params.get('dark', 1.0)
        v = max(level, floor)
        out[key] = (int(base[0] * v), int(base[1] * v), int(base[2] * v))
    return out
